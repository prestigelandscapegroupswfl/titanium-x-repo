#!/usr/bin/env python3
"""Titanium X First-Run Setup — welcome wizard.

Steps: home layout -> performance mode -> artwork toggles ->
TMDb key (stored in the Titanium X catalog add-on's settings) ->
Provider Manager offer. Writes a done-flag the Titanium X service
checks at startup, so it runs once unless re-launched manually."""
import os

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
LAYOUTS = [('Cinema', 'HomeLayoutCinema'),
           ('Netflix style', 'HomeLayoutNetflix'),
           ('Disney style', 'HomeLayoutDisney'),
           ('Apple style', 'HomeLayoutApple')]


def flag_path():
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(path, exist_ok=True)
    return os.path.join(path, 'setup-done')


def main():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno('Welcome to Titanium X',
                        'Set up your home screen, artwork and '
                        'providers in under a minute? Discovery '
                        'catalogs already work — providers are only '
                        'needed for playback.'):
        open(flag_path(), 'w').write('skipped')
        return
    pick = dialog.select('Choose your home layout',
                         [name for name, _k in LAYOUTS])
    if pick >= 0:
        for _name, key in LAYOUTS:
            xbmc.executebuiltin('Skin.SetBool(%s,%s)'
                                % (key, 'false'))
        xbmc.executebuiltin('Skin.SetBool(%s,true)'
                            % LAYOUTS[pick][1])
    mode = dialog.select('Performance mode',
                         ['Ultimate — all artwork and animation',
                          'Balanced — animated posters, no disc spin',
                          'Lite — static artwork, fastest'])
    if mode == 1:
        xbmc.executebuiltin('Skin.SetBool(DiscSpin,false)')
    elif mode == 2:
        xbmc.executebuiltin('Skin.SetBool(DiscSpin,false)')
        xbmc.executebuiltin('Skin.SetBool(ShowAnimatedPosters,false)')
    for label, key in [('Show character artwork', 'ShowCharacterArt'),
                       ('Show disc artwork', 'ShowDiscArt'),
                       ('Show clearlogos', 'ShowClearLogos')]:
        xbmc.executebuiltin('Skin.SetBool(%s,%s)'
                            % (key, 'true' if dialog.yesno(
                                'Titanium X Setup', label + '?')
                                else 'false'))
    key = dialog.input('Your free TMDb API key (optional — unlocks '
                       'every discovery catalog)', defaultt='')
    if key:
        xbmcaddon.Addon('plugin.video.titaniumx').setSetting(
            'tmdb_key', key)
    if dialog.yesno('Titanium X Setup',
                    'Open the Provider Manager now to install and '
                    'configure your playback providers?'):
        xbmc.executebuiltin('RunScript(script.titaniumx.providers)')
    open(flag_path(), 'w').write('done')
    dialog.notification('Titanium X', 'Setup complete — enjoy!',
                        time=4000)


if __name__ == '__main__':
    main()
