#!/usr/bin/env python3
"""Titanium X Artwork Service — the ecosystem's only background
service. Phase 1 scope: cache-cap enforcement (LRU) + Assets
manifest update check on a slow timer. Enrichment itself happens in
the foreground addons through the shared module.

Stability contract: this service must NEVER crash visibly, block the
interface, or raise a Kodi script-error notification. Everything
runs inside one top-level guard; any failure is logged once and the
service exits quietly. No first-run scripts, no dialogs, no network
work at import time."""
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcvfs

CAPS_GB = (1, 2, 5, 10)
ADDON = None


def enforce_cap(profile):
    from titaniumx import cache as cache_mod
    c = cache_mod.ArtworkCache(profile)
    try:
        cap_gb = CAPS_GB[int(ADDON.getSetting('cache_limit_gb') or 0)]
    except (ValueError, IndexError):
        cap_gb = 1
    cap = cap_gb * 1_000_000_000
    files = []
    total = 0
    for name in os.listdir(c.files):
        p = os.path.join(c.files, name)
        if os.path.isfile(p):
            files.append((os.path.getmtime(p), p))
            total += os.path.getsize(p)
    files.sort()  # oldest first
    for _mtime, p in files:
        if total <= cap:
            break
        total -= os.path.getsize(p)
        try:
            os.remove(p)
        except OSError:
            pass


def main():
    global ADDON
    ADDON = xbmcaddon.Addon('service.titaniumx.artwork')
    sys.path.append(xbmcvfs.translatePath(
        'special://home/addons/script.module.titaniumx.artwork/'
        'resources/lib'))
    from titaniumx import cache as cache_mod
    profile = cache_mod.shared_cache_dir()
    monitor = xbmc.Monitor()
    last = 0
    while not monitor.abortRequested():
        if time.time() - last > 1800:  # every 30 minutes
            try:
                enforce_cap(profile)
            except Exception as exc:
                xbmc.log('TitaniumX service: %s' % exc, xbmc.LOGWARNING)
            last = time.time()
        monitor.waitForAbort(10)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        # Never surface a script error to the UI. Log and exit.
        try:
            import traceback
            xbmc.log('TitaniumX service stopped on error:\n%s'
                     % traceback.format_exc(), xbmc.LOGERROR)
        except Exception:
            pass
