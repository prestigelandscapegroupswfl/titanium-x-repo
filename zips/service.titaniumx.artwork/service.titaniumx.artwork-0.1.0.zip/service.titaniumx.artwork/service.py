#!/usr/bin/env python3
"""Titanium X Artwork Service — the ecosystem's only background
service. Phase 1 scope: cache-cap enforcement (LRU) + Assets
manifest update check on a slow timer. Enrichment itself happens in
the foreground addons through the shared module."""
import os
import sys
import time

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon('service.titaniumx.artwork')
sys.path.append(xbmc.translatePath(
    'special://home/addons/script.module.titaniumx.artwork/resources/lib'))

CAPS_GB = (1, 2, 5, 10)


def enforce_cap(profile):
    from titaniumx import cache as cache_mod
    c = cache_mod.ArtworkCache(profile)
    try:
        cap_gb = CAPS_GB[int(ADDON.getSetting('cache_limit_gb') or 0)]
    except (ValueError, IndexError):
        cap_gb = 1
    cap = cap_gb * 1_000_000_000
    files = []
    total = 0
    for name in os.listdir(c.files):
        p = os.path.join(c.files, name)
        if os.path.isfile(p):
            files.append((os.path.getmtime(p), p))
            total += os.path.getsize(p)
    files.sort()  # oldest first
    for _mtime, p in files:
        if total <= cap:
            break
        total -= os.path.getsize(p)
        try:
            os.remove(p)
        except OSError:
            pass


def _firstrun_check():
    import os
    flag = xbmc.translatePath(
        'special://profile/addon_data/script.titaniumx.setup/'
        'setup-done')
    if os.path.exists(flag):
        return
    if xbmc.getCondVisibility(
            'System.HasAddon(script.titaniumx.setup)'):
        xbmc.executebuiltin('RunScript(script.titaniumx.setup)')


def main():
    profile = xbmc.translatePath(
        xbmcaddon.Addon('script.titaniumx.artwork').getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    _firstrun_check()
    monitor = xbmc.Monitor()
    last = 0
    while not monitor.abortRequested():
        if time.time() - last > 1800:  # every 30 minutes
            try:
                enforce_cap(profile)
            except Exception as exc:
                xbmc.log('TitaniumX service: %s' % exc, xbmc.LOGWARNING)
            last = time.time()
        monitor.waitForAbort(10)


if __name__ == '__main__':
    main()
