#!/usr/bin/env python3
"""Titanium X Theme Studio — UI.

Apply themes live via Kodi's lookandfeel.skincolors setting (the
skins reference named colours, so any theme works with any layout),
create custom themes (written into the active skin's colours
folder), import community themes from the Titanium X Assets
repository, export share packs, and tune the visual toggles."""
import json
import os
import sys
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
sys.path.append(os.path.join(ADDON.getAddonInfo('path'), 'resources',
                             'lib'))
import themecore  # noqa: E402

BUILTIN = ['TitaniumBlack', 'RoyalAmethyst', 'CrimsonX',
           'ElectricFusion', 'EmeraldElite', 'MidnightGold',
           'ArcticPlatinum', 'SunsetX', 'Cyberpunk', 'OceanDepth',
           'RoseTitanium', 'ToxicX']
MANIFEST = ('https://raw.githubusercontent.com/'
            'prestigelandscapegroupswfl/titanium-x-assets/master/'
            'themes/index.json')
RAW = ('https://raw.githubusercontent.com/'
       'prestigelandscapegroupswfl/titanium-x-assets/master/'
       'themes/%s.xml')


def skin_colors_dir():
    return xbmc.translatePath('special://skin/colors/')


def apply_theme(name):
    xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'method': 'Settings.SetSettingValue',
        'params': {'setting': 'lookandfeel.skincolors',
                   'value': name}, 'id': 1}))
    xbmcgui.Dialog().notification('Theme Studio',
                                  'Theme applied: %s' % name,
                                  time=3000)


def custom_themes():
    folder = skin_colors_dir()
    try:
        return sorted(f[:-4] for f in os.listdir(folder)
                      if f.endswith('.xml')
                      and f[:-4] not in BUILTIN
                      and f != 'defaults.xml')
    except Exception:
        return []


def create_theme():
    dialog = xbmcgui.Dialog()
    name = dialog.input('Theme name', defaultt='My Theme')
    if not name:
        return
    defaults = {'accent': '965CFF', 'accent2': 'D4AF37',
                'text': 'FFFFFF', 'muted': 'B0B0B0',
                'background': '0A0A12'}
    colors = {}
    for field in themecore.FIELDS:
        value = dialog.input('%s colour (hex)' % field.capitalize(),
                             defaultt=defaults[field])
        if not value:
            return
        try:
            colors[field] = themecore.normalise(value)
        except ValueError:
            dialog.ok('Theme Studio', '%s is not a hex colour.'
                      % value)
            return
    target = os.path.join(skin_colors_dir(),
                          '%s.xml' % name.replace(' ', ''))
    with open(target, 'w', encoding='utf-8') as fh:
        fh.write(themecore.theme_xml(colors))
    dialog.ok('Theme Studio',
              'Saved. Apply it here, or in Settings > Interface > '
              'Skin > Colours (if it is not listed yet, re-select '
              'the skin once so Kodi rescans the folder).')
    apply_theme(name.replace(' ', ''))


def import_theme():
    dialog = xbmcgui.Dialog()
    try:
        with urllib.request.urlopen(MANIFEST, timeout=20) as resp:
            manifest = json.loads(resp.read().decode('utf-8'))
    except Exception:
        dialog.ok('Theme Studio', 'Could not reach the Titanium X '
                                  'theme repository.')
        return
    names = [t['name'] for t in manifest.get('themes', [])]
    pick = dialog.select('Import a community theme', names)
    if pick < 0:
        return
    name = names[pick]
    with urllib.request.urlopen(RAW % name, timeout=20) as resp:
        xml_text = resp.read().decode('utf-8')
    themecore.parse_theme(xml_text)
    with open(os.path.join(skin_colors_dir(), '%s.xml' % name),
              'w', encoding='utf-8') as fh:
        fh.write(xml_text)
    apply_theme(name)


def export_theme():
    dialog = xbmcgui.Dialog()
    names = BUILTIN + custom_themes()
    pick = dialog.select('Export which theme?', names)
    if pick < 0:
        return
    name = names[pick]
    with open(os.path.join(skin_colors_dir(), '%s.xml' % name),
              encoding='utf-8') as fh:
        colors = themecore.parse_theme(fh.read())
    out_dir = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(out_dir, exist_ok=True)
    target = os.path.join(out_dir, '%s.titaniumx-theme.zip' % name)
    with open(target, 'wb') as fh:
        fh.write(themecore.make_pack(name, colors))
    dialog.ok('Theme Studio',
              'Exported to:\n%s\nSend it to the Titanium X team to '
              'publish it in the shared theme repository.' % target)


def toggle(label, key):
    on = xbmc.getCondVisibility('Skin.HasSetting(%s)' % key)
    xbmc.executebuiltin('Skin.ToggleSetting(%s)' % key)
    xbmcgui.Dialog().notification('Theme Studio',
                                  '%s %s' % (label, 'off' if on
                                             else 'on'), time=2500)


def icon_pack():
    dialog = xbmcgui.Dialog()
    pick = dialog.select('Icon pack', ['Chrome (default)', 'Neon'])
    if pick < 0:
        return
    media = xbmc.translatePath('special://skin/media/')
    pack_dir = os.path.join(media, 'iconpack_neon')
    backup = os.path.join(media, 'iconpack_chrome')
    import shutil
    if pick == 1:
        os.makedirs(backup, exist_ok=True)
        for f in os.listdir(pack_dir):
            src_icon = os.path.join(media, f)
            if os.path.exists(src_icon):
                shutil.copy(src_icon, os.path.join(backup, f))
            shutil.copy(os.path.join(pack_dir, f), src_icon)
    else:
        if os.path.isdir(backup):
            for f in os.listdir(backup):
                shutil.copy(os.path.join(backup, f),
                            os.path.join(media, f))
    xbmc.executebuiltin('ReloadSkin()')
    dialog.notification('Theme Studio', 'Icon pack applied',
                        time=3000)


def main():
    dialog = xbmcgui.Dialog()
    while True:
        pick = dialog.select('Titanium X Theme Studio', [
            'Apply a built-in theme', 'Apply a custom theme',
            'Create a custom theme', 'Import from repository',
            'Export / share a theme', 'Glass menus on/off',
            'Selection glow on/off', 'Character art: left/right',
            'Startup animation on/off', 'Icon pack',
            'Day theme (Arctic Platinum)',
            'Night theme (Titanium Black)', 'Done'])
        if pick < 0 or pick == 12:
            return
        if pick == 0:
            sel = dialog.select('Built-in themes', BUILTIN)
            if sel >= 0:
                apply_theme(BUILTIN[sel])
        elif pick == 1:
            customs = custom_themes()
            if not customs:
                dialog.ok('Theme Studio', 'No custom themes yet — '
                                          'create one first.')
            else:
                sel = dialog.select('Custom themes', customs)
                if sel >= 0:
                    apply_theme(customs[sel])
        elif pick == 2:
            create_theme()
        elif pick == 3:
            import_theme()
        elif pick == 4:
            export_theme()
        elif pick == 5:
            toggle('Glass menus', 'GlassMenus')
        elif pick == 6:
            toggle('Selection glow', 'DisableGlow')
        elif pick == 7:
            toggle('Character art left side', 'CharacterLeft')
        elif pick == 8:
            toggle('Startup animation', 'DisableStartupAnim')
        elif pick == 9:
            icon_pack()
        elif pick == 10:
            apply_theme('ArcticPlatinum')
        elif pick == 11:
            apply_theme('TitaniumBlack')


if __name__ == '__main__':
    main()
