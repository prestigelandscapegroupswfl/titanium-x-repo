#!/usr/bin/env python3
"""Theme Studio core — theme XML, validation, share packs.

A Titanium X colour theme is a Kodi skin colours file: named
colours (accent, accent2, text, muted, background) that every
Titanium X skin references, so a theme applies to any layout."""
import io
import json
import re
import zipfile
import xml.etree.ElementTree as ET

FIELDS = ('accent', 'accent2', 'text', 'muted', 'background')
HEX = re.compile(r'^[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$')


def normalise(value):
    """'965cff' / 'FF965CFF' -> 'FF965CFF' (AARRGGBB)."""
    v = value.strip().lstrip('#').upper()
    if not HEX.match(v):
        raise ValueError('not a hex colour: %s' % value)
    return v if len(v) == 8 else 'FF' + v


def theme_xml(colors):
    rows = ['<?xml version="1.0" encoding="UTF-8"?>', '<colors>']
    for field in FIELDS:
        rows.append('  <color name="%s">%s</color>'
                    % (field, normalise(colors[field])))
    rows.append('  <color name="accent_dim">FF000000</color>')
    rows.append('</colors>')
    return '\n'.join(rows) + '\n'


def parse_theme(xml_text):
    root = ET.fromstring(xml_text)
    out = {}
    for el in root.iter('color'):
        out[el.get('name')] = (el.text or '').strip()
    missing = [f for f in FIELDS if f not in out]
    if missing:
        raise ValueError('theme is missing colours: %s'
                         % ', '.join(missing))
    return out


def make_pack(name, colors):
    """A shareable theme pack: one ZIP holding <Name>.xml."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('%s.xml' % name, theme_xml(colors))
        z.writestr('theme.json', json.dumps(
            {'name': name, 'colors': {f: normalise(colors[f])
                                      for f in FIELDS}}, indent=2))
    return buf.getvalue()


def read_pack(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        meta = json.loads(z.read('theme.json').decode('utf-8'))
        xml_text = z.read('%s.xml' % meta['name']).decode('utf-8')
    parse_theme(xml_text)
    return meta['name'], xml_text
