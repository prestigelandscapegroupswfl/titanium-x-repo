#!/usr/bin/env python3
"""Titanium X prototype — persistent artwork cache (pure Python).

SQLite index + a file cache for downloaded animated artwork.
Keyed by IMDb ID; stores the chosen URL per artwork key, any local
file downloaded for it, and user overrides (which always win).
"""
import os
import sqlite3
import time
import urllib.request

SCHEMA = """
CREATE TABLE IF NOT EXISTS artwork (
    imdb TEXT NOT NULL,
    art_key TEXT NOT NULL,
    url TEXT,
    local_path TEXT,
    source TEXT,
    updated REAL,
    PRIMARY KEY (imdb, art_key)
);
CREATE TABLE IF NOT EXISTS locks (
    imdb TEXT NOT NULL,
    art_key TEXT NOT NULL,
    PRIMARY KEY (imdb, art_key)
);
CREATE TABLE IF NOT EXISTS overrides (
    imdb TEXT NOT NULL,
    art_key TEXT NOT NULL,
    url TEXT,
    local_path TEXT,
    PRIMARY KEY (imdb, art_key)
);
"""


class ArtworkCache:
    def __init__(self, profile_dir):
        self.dir = profile_dir
        self.files = os.path.join(profile_dir, 'files')
        os.makedirs(self.files, exist_ok=True)
        self.db = sqlite3.connect(os.path.join(profile_dir, 'artwork.db'))
        self.db.executescript(SCHEMA)
        self.db.commit()

    def get(self, imdb):
        """Merged art dict for a title: overrides beat cached picks."""
        out = {}
        for table in ('artwork', 'overrides'):
            rows = self.db.execute(
                'SELECT art_key, url, local_path FROM %s WHERE imdb=?'
                % table, (imdb,))
            for key, url, local in rows:
                out[key] = local or url
        return out

    def lock(self, imdb, art_key):
        self.db.execute('INSERT OR IGNORE INTO locks VALUES (?,?)',
                        (imdb, art_key))
        self.db.commit()

    def unlock(self, imdb, art_key):
        self.db.execute('DELETE FROM locks WHERE imdb=? AND art_key=?',
                        (imdb, art_key))
        self.db.commit()

    def is_locked(self, imdb, art_key):
        row = self.db.execute(
            'SELECT 1 FROM locks WHERE imdb=? AND art_key=?',
            (imdb, art_key)).fetchone()
        return row is not None

    def put(self, imdb, art, source):
        # Locked artwork is never replaced by automatic refresh.
        art = {k: v for k, v in art.items()
               if not self.is_locked(imdb, k)}
        rows = [(imdb, k, v, None, source, time.time())
                for k, v in art.items() if v]
        self.db.executemany(
            'INSERT OR REPLACE INTO artwork VALUES (?,?,?,?,?,?)', rows)
        self.db.commit()

    def set_local(self, imdb, art_key, local_path, source='download'):
        self.db.execute(
            'INSERT OR REPLACE INTO artwork VALUES (?,?,?,?,?,?)',
            (imdb, art_key, None, local_path, source, time.time()))
        self.db.commit()

    def set_override(self, imdb, art_key, url=None, local_path=None):
        self.db.execute(
            'INSERT OR REPLACE INTO overrides VALUES (?,?,?,?)',
            (imdb, art_key, url, local_path))
        self.db.commit()

    def download(self, imdb, art_key, url):
        """Download a file (animated GIFs) into the local cache so
        Kodi can animate it from the local filesystem. Returns the
        local path or '' on failure."""
        ext = os.path.splitext(url.split('?')[0])[1] or '.gif'
        dest = os.path.join(self.files, '%s_%s%s' % (imdb, art_key, ext))
        if os.path.exists(dest) and os.path.getsize(dest) > 0:
            return dest
        try:
            req = urllib.request.Request(
                url, headers={'User-Agent': 'TitaniumX-Prototype/0.1.0'})
            with urllib.request.urlopen(req, timeout=60) as resp, \
                    open(dest, 'wb') as out:
                out.write(resp.read())
            return dest
        except Exception:
            return ''

    def stats(self):
        n = self.db.execute('SELECT COUNT(DISTINCT imdb) FROM artwork')
        return {'titles': n.fetchone()[0]}


    def watchlist_add(self, imdb, title):
        _watchlist_init(self.db)
        self.db.execute(
            'INSERT OR REPLACE INTO watchlist VALUES (?,?,?)',
            (imdb, title, __import__('time').time()))
        self.db.commit()

    def watchlist_remove(self, imdb):
        _watchlist_init(self.db)
        self.db.execute('DELETE FROM watchlist WHERE imdb=?', (imdb,))
        self.db.commit()

    def watchlist(self):
        _watchlist_init(self.db)
        rows = self.db.execute(
            'SELECT imdb, title FROM watchlist ORDER BY added DESC'
        ).fetchall()
        return [{'imdb': r[0], 'title': r[1]} for r in rows]

    def find_duplicates(self):
        """Duplicate detection: local cache files with identical
        content (md5) stored under different titles/keys."""
        import hashlib
        by_hash = {}
        for name in os.listdir(self.files):
            path = os.path.join(self.files, name)
            if not os.path.isfile(path):
                continue
            digest = hashlib.md5()
            with open(path, 'rb') as fh:
                for chunk in iter(lambda: fh.read(65536), b''):
                    digest.update(chunk)
            by_hash.setdefault(digest.hexdigest(), []).append(name)
        return {h: names for h, names in by_hash.items()
                if len(names) > 1}


def _watchlist_init(db):
    db.execute('CREATE TABLE IF NOT EXISTS watchlist '
               '(imdb TEXT PRIMARY KEY, title TEXT, added REAL)')
    db.commit()


def shared_cache_dir():
    """The ONE cache location for the whole ecosystem (the module's
    own addon_data), so the plugin, Downloader Pro and the service
    all read/write the same artwork cache."""
    import os
    import xbmc
    path = xbmc.translatePath(
        'special://profile/addon_data/script.module.titaniumx.artwork')
    os.makedirs(path, exist_ok=True)
    return path
