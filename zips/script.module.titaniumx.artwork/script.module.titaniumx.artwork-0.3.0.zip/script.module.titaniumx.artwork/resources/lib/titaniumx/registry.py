#!/usr/bin/env python3
"""Titanium X framework — provider registry.

Providers are consulted in priority order. User overrides (stored in
the cache DB) always win and are applied by the cache layer itself,
above every provider. Each provider declares: id, label, whether it
needs an API key, and an availability probe. New providers register
here without touching the skin or the enrichment core.
"""

DEFAULT_ORDER = ('override', 'repo', 'fanarttv', 'tmdb', 'cinemeta',
                 'motion', 'discsynth', 'import')

PROVIDERS = {
    'override': {
        'label': 'User overrides (Artwork Manager)',
        'needs_key': None,
        'note': 'Artwork the user picked or imported; always wins.',
    },
    'repo': {
        'label': 'Titanium X Assets + user artwork repositories',
        'needs_key': None,
        'note': 'Manifest-indexed packs (index.json by IMDb/TMDb/TVDb ID).',
    },
    'fanarttv': {
        'label': 'fanart.tv',
        'needs_key': 'fanarttv_key',
        'note': 'Disc art, clearart, character art (TV), banners, logos.',
    },
    'tmdb': {
        'label': 'TMDb',
        'needs_key': 'tmdb_key',
        'note': 'Keyart (textless posters), alternates, backdrops, logos.',
    },
    'cinemeta': {
        'label': 'Cinemeta (keyless base)',
        'needs_key': None,
        'note': 'Poster, fanart, clearlogo and IDs for any title.',
    },
    'motion': {
        'label': 'Motion Artwork Engine (generated)',
        'needs_key': None,
        'note': 'Renders subtle animated GIFs from static art. '
                'Generated artwork is labelled as generated.',
    },
    'discsynth': {
        'label': 'Disc synthesis (generated)',
        'needs_key': None,
        'note': 'Builds a disc image from the poster when no official '
                'disc art exists. Labelled as generated.',
    },
    'import': {
        'label': 'Local imports',
        'needs_key': None,
        'note': 'Files the user imported through the Artwork Manager.',
    },
}


def availability(settings):
    """{provider_id: 'available' | 'needs key' | 'not configured'}"""
    out = {}
    for pid, meta in PROVIDERS.items():
        key_setting = meta['needs_key']
        if key_setting is None:
            out[pid] = 'available'
        else:
            out[pid] = 'available' if settings.get(key_setting) \
                else 'needs key'
    return out
