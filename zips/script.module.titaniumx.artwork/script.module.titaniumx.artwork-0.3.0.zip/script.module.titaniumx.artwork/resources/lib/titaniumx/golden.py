#!/usr/bin/env python3
"""Titanium X — Golden Catalogue importer/executor (pure Python).

Parses Golden's data/collections.json (MIT licensed) into Titanium X
collections/folders, and executes each folder's declarative spec
ON-DEVICE:
  * list      -> MDBList JSON feed (KEYLESS)
  * trending  -> TMDb /trending
  * collection-> TMDb /collection/{id} (franchise parts)
  * parts     -> several collections + individual movies merged
  * company / person / keyword / genre / language / network /
    provider / discover -> TMDb /discover with mapped filters
Items come back TMDb-keyed ({tmdb, title, poster, fanart, year});
the Artwork Engine enriches by TMDb ID (fanart.tv accepts it for
movies), so imported listings receive the same enrichment as native
Titanium X listings. Nothing enters the Kodi library.
"""
import datetime
import json
import re
import urllib.request

UA = {'User-Agent': 'TitaniumX-Prototype/0.1.0'}
TMDB = 'https://api.themoviedb.org/3'
IMG = 'https://image.tmdb.org/t/p/'

# Golden provider brand slugs -> TMDb watch-provider IDs (US region).
PROVIDERS = {
    'netflix': 8, 'hulu': 15, 'prime': 9, 'amazon': 9, 'disney': 337,
    'hbo': 384, 'max': 1899, 'apple': 350, 'paramount': 531,
    'peacock': 386, 'showtime': 37, 'starz': 43,
}


def _get_json(url, headers=None, timeout=30):
    req = urllib.request.Request(url, headers=dict(UA, **(headers or {})))
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def parse_pack(data):
    """Golden pack JSON -> [{id, title, folders: [{id, title, spec}]}]"""
    cols = data if isinstance(data, list) else data.get('collections', [])
    out = []
    for c in cols:
        folders = []
        for f in c.get('folders', []):
            spec = {k: v for k, v in f.items() if k not in ('id', 'title')}
            folders.append({'id': f.get('id'), 'title': f.get('title'),
                            'spec': spec})
        out.append({'id': c.get('id'), 'title': c.get('title'),
                    'tileShape': c.get('tileShape'), 'folders': folders})
    return out


def spec_kind(spec):
    for kind in ('list', 'collection', 'parts', 'trending', 'discover',
                 'company', 'person', 'keyword', 'genre', 'language',
                 'network', 'provider'):
        if kind in spec:
            return kind
    return 'unknown'


def _resolve_templates(value):
    """Golden uses {{now}}, {{now-120d}}, {{now+1d}} in date params."""
    if not isinstance(value, str):
        return value
    def repl(m):
        expr = m.group(1)
        mm = re.match(r'now(?:([+-])(\d+)d)?$', expr)
        if not mm:
            return value
        today = datetime.date.today()
        if mm.group(1):
            delta = datetime.timedelta(days=int(mm.group(2)))
            today = today + delta if mm.group(1) == '+' else today - delta
        return today.isoformat()
    return re.sub(r'\{\{([^}]+)\}\}', repl, value)


def _meta(item, media_type):
    poster = item.get('poster_path')
    backdrop = item.get('backdrop_path')
    return {
        'tmdb': item.get('id'),
        'imdb': item.get('imdb_id') or '',
        'title': item.get('title') or item.get('name') or '',
        'year': (item.get('release_date') or item.get('first_air_date')
                 or '')[:4],
        'poster': (IMG + 'w500' + poster) if poster else '',
        'fanart': (IMG + 'original' + backdrop) if backdrop else '',
        'media_type': media_type,
        'rating': str(item.get('vote_average') or ''),
        'plot': item.get('overview') or '',
    }


def _tmdb(path, key, params=None):
    qs = dict(params or {})
    url = TMDB + path
    if key.startswith('eyJ'):
        headers = {'Authorization': 'Bearer ' + key}
    else:
        headers = None
        qs['api_key'] = key
    if qs:
        url += '?' + '&'.join('%s=%s' % (k, urllib.parse.quote(str(v)))
                              for k, v in qs.items())
    return _get_json(url, headers=headers)


import urllib.parse  # noqa: E402


def _discover(spec, key, media):
    """Build TMDb discover params from a Golden folder spec."""
    params = {'sort_by': 'popularity.desc', 'page': 1}
    base = spec.get('discover', {}).get(media, {}) \
        if isinstance(spec.get('discover'), dict) else {}
    for k, v in base.items():
        params[k] = _resolve_templates(v)
    for k, v in (spec.get('params') or {}).items():
        params[k] = _resolve_templates(v)
    if 'company' in spec:
        params['with_companies'] = spec['company']
    if 'person' in spec:
        params['with_people'] = spec['person']
    if 'keyword' in spec:
        params['with_keywords'] = spec['keyword']
    if 'language' in spec:
        params['with_original_language'] = spec['language']
    if 'genre' in spec:
        g = spec['genre']
        gid = g.get(media) if isinstance(g, dict) else g
        if gid:
            params['with_genres'] = gid
    if 'network' in spec and media == 'series':
        params['with_networks'] = spec['network']
    if 'provider' in spec:
        pid = PROVIDERS.get(str(spec['provider']).lower())
        if pid:
            params['with_watch_providers'] = pid
            params['watch_region'] = 'US'
    path = '/discover/movie' if media == 'movie' else '/discover/tv'
    data = _tmdb(path, key, params)
    return [_meta(r, media) for r in data.get('results', [])]


def execute_folder(folder, tmdb_key='', limit=20):
    """Run one folder's spec -> list of item dicts (may be empty when
    a TMDb key is required but absent)."""
    spec = folder['spec']
    kind = spec_kind(spec)
    types = spec.get('types') or ['movie', 'series']
    media_types = ['movie' if t == 'movie' else 'series' for t in types]

    if kind == 'list':  # KEYLESS — MDBList JSON feeds
        items = []
        for media in media_types:
            url = (spec['list'] or {}).get(media)
            if not url:
                continue
            try:
                feed = _get_json(url)
            except Exception:
                continue
            rows = feed if isinstance(feed, list) else feed.get('items', [])
            for r in rows[:limit]:
                items.append({
                    'tmdb': r.get('tmdb_id') or r.get('id'),
                    'imdb': r.get('imdb_id') or '',
                    'title': r.get('title') or r.get('name') or '',
                    'year': str(r.get('year') or '')[:4],
                    'poster': '', 'fanart': '',
                    'media_type': media,
                    'rating': str(r.get('imdb_rating') or ''),
                    'plot': '',
                })
        return items[:limit]

    if not tmdb_key:
        return []

    if kind == 'collection':
        data = _tmdb('/collection/%s' % spec['collection'], tmdb_key)
        parts = sorted(data.get('parts', []),
                       key=lambda p: p.get('release_date') or '')
        return [_meta(p, 'movie') for p in parts][:limit]

    if kind == 'parts':
        items, seen = [], set()
        for cid in (spec['parts'].get('collections') or []):
            data = _tmdb('/collection/%s' % cid, tmdb_key)
            for p in data.get('parts', []):
                if p['id'] not in seen:
                    seen.add(p['id'])
                    items.append(_meta(p, 'movie'))
        for mid in (spec['parts'].get('movies') or []):
            data = _tmdb('/movie/%s' % mid, tmdb_key)
            if data.get('id') not in seen:
                items.append(_meta(data, 'movie'))
        return items[:limit]

    if kind == 'trending':
        items = []
        for media in media_types:
            path = '/trending/%s/week' % ('movie' if media == 'movie'
                                           else 'tv')
            data = _tmdb(path, tmdb_key)
            items += [_meta(r, media) for r in data.get('results', [])]
        return items[:limit]

    items = []
    for media in media_types:
        if 'network' in spec and media == 'movie':
            continue
        items += _discover(spec, tmdb_key, media)
    return items[:limit]
