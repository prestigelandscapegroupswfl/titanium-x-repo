#!/usr/bin/env python3
"""Titanium X framework — the 33 artwork categories (spec section 2).

Every category is individually enable/disable-able. `keys` are the
artwork keys the engine resolves for the category; `sources` names
the providers that can supply it. Availability is honest: a category
with no live source is still listed (never hidden), and diagnostics
report it as unavailable rather than pretending it downloaded.
"""

CATEGORIES = [
    # Posters and Keyart
    ('poster', 'Standard posters', ('poster',), ('cinemeta', 'tmdb', 'fanarttv', 'repo')),
    ('animatedposter', 'Animated posters', ('animatedposter',), ('repo', 'motion', 'import')),
    ('poster2', 'Extra posters', ('poster2', 'poster3'), ('fanarttv', 'tmdb')),
    ('textlessposter', 'Textless posters', ('textlessposter',), ('tmdb',)),
    ('keyart', 'Keyart', ('keyart',), ('tmdb', 'repo')),
    ('keyart2', 'Extra keyart', ('keyart2',), ('tmdb', 'repo')),
    ('animatedkeyart', 'Animated keyart', ('animatedkeyart',), ('repo', 'motion', 'import')),
    # Character artwork
    ('characterart', 'Character PNGs', ('characterart',), ('fanarttv', 'repo', 'import')),
    ('characterart2', 'Extra character art', ('characterart2',), ('fanarttv', 'repo')),
    ('clearart', 'Clearart', ('clearart',), ('fanarttv', 'tmdb')),
    ('clearart2', 'Extra clearart', ('clearart2',), ('fanarttv',)),
    ('actorportraits', 'Actor portraits', ('actor1', 'actor2', 'actor3'), ('tmdb',)),
    ('characterrenders', 'Transparent character renders', ('characterrender',), ('repo', 'import')),
    # Background artwork
    ('fanart', 'Fanart', ('fanart',), ('cinemeta', 'tmdb', 'fanarttv', 'repo')),
    ('extrafanart', 'Extra fanart', ('fanart1', 'fanart2', 'fanart3', 'fanart4'), ('fanarttv', 'tmdb')),
    ('animatedfanart', 'Animated fanart', ('animatedfanart',), ('repo', 'motion', 'import')),
    ('landscape', 'Landscape artwork', ('landscape',), ('fanarttv', 'tmdb')),
    ('videobackground', 'Video backgrounds', ('videobackground',), ('skin',)),
    # Logos and media artwork
    ('clearlogo', 'Clearlogos', ('clearlogo',), ('cinemeta', 'fanarttv', 'tmdb', 'repo')),
    ('clearlogo2', 'Extra clearlogos', ('clearlogo2',), ('tmdb', 'fanarttv')),
    ('discart', 'Disc art', ('discart',), ('fanarttv', 'repo', 'discsynth')),
    ('animateddiscart', 'Animated disc art', ('animateddiscart',), ('repo', 'motion')),
    ('bluraycover', 'Blu-ray covers', ('bluraycover',), ('repo', 'import')),
    ('case3d', '3D case artwork', ('case3d',), ('skin',)),
    ('studiologos', 'Studio logos', ('studiologo',), ('tmdb', 'repo')),
    ('networklogos', 'Network logos', ('networklogo',), ('tmdb', 'repo')),
    # Collections and television
    ('collectionposter', 'Collection posters', ('collectionposter',), ('tmdb', 'repo')),
    ('animatedcollectioncover', 'Animated collection covers', ('animatedcollectioncover',), ('repo', 'motion')),
    ('genreart', 'Genre artwork', ('genreart',), ('repo',)),
    ('seasonposter', 'Season posters', ('seasonposter',), ('tmdb', 'fanarttv')),
    ('episodethumb', 'Episode thumbnails', ('episodethumb',), ('tmdb',)),
    ('tvbanner', 'TV banners', ('banner',), ('fanarttv', 'tmdb')),
    ('decadeart', 'Decade artwork', ('decadeart',), ('repo',)),
]

BY_ID = {c[0]: c for c in CATEGORIES}


def all_keys():
    keys = []
    for _cid, _label, ks, _src in CATEGORIES:
        keys.extend(ks)
    return keys
