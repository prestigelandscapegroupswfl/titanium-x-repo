#!/usr/bin/env python3
"""Titanium X prototype — addon entry point.

Routes (all dynamic; nothing is ever added to the Kodi library):
  root            -> menu: Movies / TV / Golden Catalogue / Showcase /
                     Diagnostics
  ?action=movies  -> 20 popular movies (Cinemeta), fully enriched
  ?action=series  -> 20 popular series (Cinemeta), base + enrichment
  ?action=golden  -> Golden Catalogue collections (imported by URL)
  ?action=golden_collection&cid=.. -> its folders
  ?action=golden_folder&cid=..&fid=.. -> folder items, enriched with
                     the same Artwork Engine pass as native listings
  ?action=showcase&source=.. -> cinematic Showcase window
  ?action=diagnostics -> diagnostics window
Playback is intentionally NOT handled here: in the full build,
items hand off to the authorized player routing (TMDb Helper/Torus).
"""
import json
import os
import sys
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE = sys.argv[0] if sys.argv else 'plugin://plugin.video.titaniumx/'

sys.path.insert(0, os.path.join(ADDON.getAddonInfo('path'),
                                'resources', 'lib'))
import cache as cache_mod      # noqa: E402
import diagnostics             # noqa: E402
import enrich                  # noqa: E402
import golden                  # noqa: E402
import providers               # noqa: E402

GOLDEN_URL = ('https://raw.githubusercontent.com/0x8e8fb-p/'
              'nuvio-golden-catalogue/master/data/collections.json')


def profile_dir():
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(path, exist_ok=True)
    return path


def get_cache():
    return cache_mod.ArtworkCache(profile_dir())


def keys():
    return ADDON.getSetting('fanarttv_key'), ADDON.getSetting('tmdb_key')


def load_golden():
    """Fetch (and locally cache) the Golden Catalogue pack."""
    cached = os.path.join(profile_dir(), 'golden_pack.json')
    try:
        req = urllib.request.Request(
            GOLDEN_URL, headers={'User-Agent': 'TitaniumX/0.1.0'})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        with open(cached, 'w') as fh:
            json.dump(data, fh)
    except Exception:
        if not os.path.exists(cached):
            raise
        with open(cached) as fh:
            data = json.load(fh)
    return golden.parse_pack(data)


def make_item(m, action_url=None):
    li = xbmcgui.ListItem(label=m['title'])
    art = dict(m.get('art') or {})
    art.setdefault('poster', m.get('poster', ''))
    art.setdefault('fanart', m.get('fanart', ''))
    art.setdefault('thumb', art.get('poster', ''))
    art.setdefault('icon', art.get('poster', ''))
    li.setArt(art)
    info = li.getVideoInfoTag()
    info.setTitle(m['title'])
    year = str(m.get('year') or '')
    if year[:4].isdigit():
        info.setYear(int(year[:4]))
    info.setPlot(m.get('plot') or '')
    rating = m.get('rating')
    if rating:
        try:
            info.setRating(float(rating))
        except (TypeError, ValueError):
            pass
    if m.get('genres'):
        info.setGenres(m['genres'])
    if m.get('cast'):
        info.setCast([xbmc.Actor(name=c) for c in m['cast']])
    if m.get('imdb'):
        li.setProperty('imdb', m['imdb'])
    if m.get('tmdb'):
        li.setProperty('tmdb', str(m['tmdb']))
    return li


def list_movies():
    fanart_key, tmdb_key = keys()
    movies = enrich.enrich_catalog(get_cache(), fanart_key, tmdb_key,
                                   limit=20)
    entries = []
    for m in movies:
        li = make_item(m)
        url = '%s?action=showcase&source=movies&imdb=%s' % (BASE,
                                                            m['imdb'])
        entries.append((url, li, False))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)


def list_series():
    fanart_key, tmdb_key = keys()
    shows = providers.cinemeta_series(20)
    shows = enrich.enrich_items(shows, get_cache(), fanart_key, tmdb_key)
    entries = []
    for s in shows:
        li = make_item(s)
        url = '%s?action=showcase&source=series&imdb=%s' % (BASE,
                                                           s['imdb'])
        entries.append((url, li, False))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    xbmcplugin.setContent(HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE)


def list_golden_collections():
    cols = load_golden()
    entries = []
    for c in cols:
        li = xbmcgui.ListItem(label='%s (%d folders)'
                                % (c['title'], len(c['folders'])))
        url = '%s?action=golden_collection&cid=%s' % (BASE, c['id'])
        entries.append((url, li, True))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    xbmcplugin.endOfDirectory(HANDLE)


def list_golden_folders(cid):
    cols = load_golden()
    col = next((c for c in cols if c['id'] == cid), None)
    entries = []
    if col:
        for f in col['folders']:
            li = xbmcgui.ListItem(label=f['title'])
            url = ('%s?action=golden_folder&cid=%s&fid=%s'
                   % (BASE, cid, f['id']))
            entries.append((url, li, True))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    xbmcplugin.endOfDirectory(HANDLE)


def list_golden_items(cid, fid):
    fanart_key, tmdb_key = keys()
    cols = load_golden()
    col = next((c for c in cols if c['id'] == cid), None)
    folder = next((f for f in (col or {}).get('folders', [])
                   if f['id'] == fid), None)
    entries = []
    if folder:
        items = golden.execute_folder(folder, tmdb_key, limit=20)
        items = enrich.enrich_items(items, get_cache(), fanart_key,
                                    tmdb_key)
        for m in items:
            li = make_item(m)
            url = ('%s?action=showcase&source=golden:%s:%s&imdb=%s'
                   % (BASE, cid, fid, m.get('imdb') or ''))
            entries.append((url, li, False))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)


def root_menu():
    entries = []
    for label, action in (
            ('Popular Movies (dynamic, no library)', 'movies'),
            ('Popular TV (dynamic, no library)', 'series'),
            ('Golden Catalogue (imported collections)', 'golden'),
            ('Titanium X Showcase', 'showcase'),
            ('Diagnostics', 'diagnostics')):
        li = xbmcgui.ListItem(label=label)
        folder = action in ('movies', 'series', 'golden')
        entries.append(('%s?action=%s' % (BASE, action), li, folder))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    xbmcplugin.endOfDirectory(HANDLE)


def source_items(source):
    fanart_key, tmdb_key = keys()
    if source == 'series':
        return enrich.enrich_items(providers.cinemeta_series(20),
                                   get_cache(), fanart_key, tmdb_key)
    if source.startswith('golden:'):
        _, cid, fid = source.split(':', 2)
        cols = load_golden()
        col = next((c for c in cols if c['id'] == cid), None)
        folder = next((f for f in (col or {}).get('folders', [])
                       if f['id'] == fid), None)
        if folder:
            items = golden.execute_folder(folder, tmdb_key, limit=20)
            return enrich.enrich_items(items, get_cache(), fanart_key,
                                       tmdb_key)
        return []
    return enrich.enrich_catalog(get_cache(), fanart_key, tmdb_key,
                                 limit=20)


def open_showcase(source='movies', imdb=''):
    import showcase
    win = showcase.ShowcaseWindow(
        'TitaniumShowcase.xml', ADDON.getAddonInfo('path'),
        movies=source_items(source), cache=get_cache(),
        motion_enabled=ADDON.getSettingBool('motion_render'),
        focus_imdb=imdb)
    win.doModal()
    del win


def open_diagnostics():
    import diag
    fanart_key, tmdb_key = keys()
    cache = get_cache()
    movies = enrich.enrich_catalog(cache, fanart_key, tmdb_key, limit=20)
    status = {'Cinemeta movies': 'OK (keyless, live)',
              'Cinemeta series': 'OK (keyless, live)',
              'Golden Catalogue': 'pack cached locally',
              'fanart.tv': 'key set' if fanart_key else 'no key — base art only',
              'TMDb': 'key set' if tmdb_key else 'no key — Golden spec folders paused'}
    lines = diagnostics.build_report(movies, cache, status)
    win = diag.DiagnosticsWindow('TitaniumDiagnostics.xml',
                                 ADDON.getAddonInfo('path'), lines=lines)
    win.doModal()
    del win


def main():
    params = urllib.parse.parse_qs(sys.argv[2].lstrip('?'))
    action = params.get('action', [''])[0]
    if action == 'movies':
        list_movies()
    elif action == 'series':
        list_series()
    elif action == 'golden':
        list_golden_collections()
    elif action == 'golden_collection':
        list_golden_folders(params.get('cid', [''])[0])
    elif action == 'golden_folder':
        list_golden_items(params.get('cid', [''])[0],
                          params.get('fid', [''])[0])
    elif action == 'showcase':
        open_showcase(params.get('source', ['movies'])[0],
                      params.get('imdb', [''])[0])
    elif action == 'diagnostics':
        open_diagnostics()
    else:
        root_menu()


if __name__ == '__main__':
    main()
