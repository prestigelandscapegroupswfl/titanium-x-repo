#!/usr/bin/env python3
"""Titanium X prototype — data providers (pure Python, no Kodi imports).

Sources, in order of use:
  * Cinemeta (keyless): the 20-movie popular catalog + base art
    (poster, clearlogo, fanart) and IMDb/TMDb IDs for every item.
  * fanart.tv (personal API key in settings): discart, clearart,
    clearlogo upgrades, character art, banners, alternate posters,
    extra fanart — fetched by IMDb ID.
  * TMDb (API key in settings): keyart (textless posters), alternate
    posters, extra backdrops, second clearlogo.

Every function returns plain dicts/lists and never raises for a
missing key — enrichment degrades gracefully to whatever is available.
"""
import json
import urllib.request

UA = {'User-Agent': 'TitaniumX-Prototype/0.1.0'}
CINEMETA_TOP = 'https://v3-cinemeta.strem.io/catalog/movie/top.json'
FANART_MOVIE = 'https://webservice.fanart.tv/v3/movies/{imdb}'
TMDB_IMAGES = 'https://api.themoviedb.org/3/movie/{tmdb}/images'


def _get_json(url, headers=None, timeout=30):
    req = urllib.request.Request(url, headers=dict(UA, **(headers or {})))
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def cinemeta_popular(limit=20):
    """Keyless popular-movies catalog. Returns a list of movie dicts:
    {imdb, tmdb, title, year, poster, fanart, clearlogo, rating, plot,
     cast (names), genres}."""
    data = _get_json(CINEMETA_TOP)
    movies = []
    for meta in data.get('metas', [])[:limit]:
        imdb = meta.get('imdb_id') or meta.get('id')
        if not imdb:
            continue
        poster = (meta.get('poster') or '').replace('/small/', '/large/')
        fanart = (meta.get('background') or '').replace('/medium/', '/large/')
        movies.append({
            'imdb': imdb,
            'tmdb': meta.get('moviedb_id'),
            'title': meta.get('name', ''),
            'year': str(meta.get('year') or meta.get('releaseInfo') or ''),
            'poster': poster,
            'fanart': fanart,
            'clearlogo': meta.get('logo') or '',
            'rating': str(meta.get('imdbRating') or ''),
            'plot': meta.get('description') or '',
            'cast': [c for c in (meta.get('cast') or [])][:6],
            'genres': meta.get('genres') or [],
            'runtime': meta.get('runtime') or '',
        })
    return movies


def _first(entries, *prefer_hd):
    """Pick the best fanart.tv entry: highest likes, HD class first."""
    if not entries:
        return ''
    pool = list(entries)
    for key in prefer_hd:
        hd = [e for e in pool if e.get('url', '').find(key) >= 0]
        if hd:
            pool = hd
            break
    pool.sort(key=lambda e: int(e.get('likes') or 0), reverse=True)
    return pool[0].get('url', '')


def _all(entries, limit=4):
    if not entries:
        return []
    pool = sorted(entries, key=lambda e: int(e.get('likes') or 0), reverse=True)
    return [e.get('url', '') for e in pool[:limit] if e.get('url')]


def fanarttv_movie(imdb, api_key):
    """fanart.tv enrichment for one movie by IMDb ID. Returns an art
    dict using Titanium X keys; empty dict when no key/no match."""
    if not api_key or not imdb:
        return {}
    try:
        data = _get_json(FANART_MOVIE.format(imdb=imdb),
                         headers={'api-key': api_key})
    except Exception:
        return {}
    art = {}
    disc = _first(data.get('moviedisc'))
    if disc:
        art['discart'] = disc
    clearart = _all(data.get('hdmovieclearart') or data.get('movieart'), 2)
    if clearart:
        art['clearart'] = clearart[0]
        if len(clearart) > 1:
            art['clearart2'] = clearart[1]
    logo = _first(data.get('hdmovielogo') or data.get('movielogo'))
    if logo:
        art['clearlogo'] = logo
    chars = _all(data.get('characterart'), 2)
    if chars:
        art['characterart'] = chars[0]
        if len(chars) > 1:
            art['characterart2'] = chars[1]
    posters = _all(data.get('movieposter'), 3)
    if posters:
        art['poster2'] = posters[0]
    fanart = _all(data.get('moviebackground'), 4)
    for i, url in enumerate(fanart):
        art['fanart%d' % (i + 1)] = url
    banner = _first(data.get('moviebanner'))
    if banner:
        art['banner'] = banner
    thumb = _first(data.get('moviethumb'))
    if thumb:
        art['landscape'] = thumb
    return art


def tmdb_images(tmdb_id, api_key):
    """TMDb image enrichment: keyart = best textless poster (no
    language = no text on the poster), alternates, extra backdrops,
    a second clearlogo."""
    if not api_key or not tmdb_id:
        return {}
    try:
        data = _get_json(TMDB_IMAGES.format(tmdb=tmdb_id),
                         headers={'Authorization': 'Bearer ' + api_key}
                         if api_key.startswith('eyJ') else None,
                         timeout=30) if api_key.startswith('eyJ') else \
            _get_json(TMDB_IMAGES.format(tmdb=tmdb_id) +
                      '?api_key=' + api_key)
    except Exception:
        return {}
    base = 'https://image.tmdb.org/t/p/original'
    art = {}

    def path(entry):
        return base + entry['file_path'] if entry.get('file_path') else ''

    posters = sorted(data.get('posters') or [],
                     key=lambda e: e.get('vote_average', 0), reverse=True)
    textless = [p for p in posters if not p.get('iso_639_1')]
    if textless:
        art['keyart'] = path(textless[0])
        if len(textless) > 1:
            art['keyart2'] = path(textless[1])
    if posters and 'poster2' not in art:
        art['poster2'] = path(posters[0])
    backdrops = sorted(data.get('backdrops') or [],
                       key=lambda e: e.get('vote_average', 0), reverse=True)
    for i, bd in enumerate(backdrops[:4]):
        art.setdefault('fanart%d' % (i + 1), path(bd))
    logos = sorted(data.get('logos') or [],
                   key=lambda e: e.get('vote_average', 0), reverse=True)
    if logos:
        art['clearlogo2'] = path(logos[0])
    return art


def cinemeta_series(limit=20):
    """Keyless popular-series catalog (same shape as cinemeta_popular)."""
    data = _get_json('https://v3-cinemeta.strem.io/catalog/series/top.json')
    shows = []
    for meta in data.get('metas', [])[:limit]:
        imdb = meta.get('imdb_id') or meta.get('id')
        if not imdb:
            continue
        shows.append({
            'imdb': imdb,
            'tmdb': meta.get('moviedb_id'),
            'title': meta.get('name', ''),
            'year': str(meta.get('year') or meta.get('releaseInfo') or ''),
            'poster': (meta.get('poster') or '').replace('/small/', '/large/'),
            'fanart': (meta.get('background') or '').replace('/medium/', '/large/'),
            'clearlogo': meta.get('logo') or '',
            'rating': str(meta.get('imdbRating') or ''),
            'plot': meta.get('description') or '',
            'cast': [c for c in (meta.get('cast') or [])][:6],
            'genres': meta.get('genres') or [],
            'runtime': meta.get('runtime') or '',
            'media_type': 'series',
        })
    return shows


def cinemeta_meta(imdb, media_type='movie'):
    """Keyless per-title meta by IMDb ID — base art for ANY title
    (used for imported listings that arrive without artwork)."""
    if not imdb:
        return {}
    try:
        data = _get_json('https://v3-cinemeta.strem.io/meta/%s/%s.json'
                         % (media_type, imdb))
    except Exception:
        return {}
    meta = data.get('meta') or {}
    if not meta:
        return {}
    return {
        'poster': (meta.get('poster') or '').replace('/small/', '/large/'),
        'fanart': (meta.get('background') or '').replace('/medium/', '/large/'),
        'clearlogo': meta.get('logo') or '',
    }
