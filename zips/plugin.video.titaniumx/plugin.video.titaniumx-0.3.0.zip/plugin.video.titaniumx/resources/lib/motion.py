#!/usr/bin/env python3
"""Titanium X Motion Artwork Engine (prototype) — pure Python + Pillow.

Creates SUBTLE animated GIFs from static artwork so Titanium X does
not depend on any external animated-art database:
  * ken_burns(): a slow 100% -> 108% zoom drifting toward a point of
    interest — reads as a living poster/backdrop, not a cartoon.
Rendered GIFs are cached locally by the caller; Kodi animates local
files, which is what makes animated posters possible on dynamic
catalog items.

Discipline (Shield-friendly): output width capped, ~2.4 s loop,
palette-optimized frames.
"""
import io
import os
import urllib.request

from PIL import Image

FRAMES = 20
DURATION_MS = 120
POSTER_W = 360
FANART_W = 640


def _load(source):
    if source.startswith('http'):
        req = urllib.request.Request(
            source, headers={'User-Agent': 'TitaniumX-Prototype/0.1.0'})
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = resp.read()
        return Image.open(io.BytesIO(data)).convert('RGB')
    return Image.open(source).convert('RGB')


def ken_burns(source, dest, width=FANART_W, zoom=1.08):
    """Render a slow-zoom GIF from a static image. Returns dest path
    or '' on failure. Zoom eases in-out; the loop point crossfades by
    ping-ponging (forward then reverse) so there is no jump cut."""
    try:
        img = _load(source)
    except Exception:
        return ''
    w, h = img.size
    if w > width:
        img = img.resize((width, int(h * width / w)), Image.LANCZOS)
        w, h = img.size
    frames = []
    steps = FRAMES // 2
    for i in range(steps):
        t = i / max(steps - 1, 1)
        ease = t * t * (3 - 2 * t)  # smoothstep
        scale = 1.0 + (zoom - 1.0) * ease
        cw, ch = int(w / scale), int(h / scale)
        cx, cy = (w - cw) // 2, (h - ch) // 2
        frame = img.crop((cx, cy, cx + cw, cy + ch)).resize((w, h),
                                                            Image.LANCZOS)
        frames.append(frame)
    frames = frames + frames[-2:0:-1]  # ping-pong back
    pal = frames[0].quantize(colors=128, method=Image.MEDIANCUT)
    qframes = [f.quantize(palette=pal, dither=Image.FLOYDSTEINBERG)
               for f in frames]
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    qframes[0].save(dest, save_all=True, append_images=qframes[1:],
                    duration=DURATION_MS, loop=0, optimize=True)
    return dest
