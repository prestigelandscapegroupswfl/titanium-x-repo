#!/usr/bin/env python3
"""Titanium X prototype — cinematic Showcase window (WindowXML).

The window's stage (fullscreen fanart, clearlogo, character art,
spinning disc, keyart) is driven by Kodi's own skin engine through
Container(9000).ListItem.Art(<key>) infolabels — the same mechanism
real skins use — so the focused item's full custom artwork set is
always on stage. A light monitor thread renders a Motion Engine
animated poster for the focused title when none exists yet.
"""
import os
import threading

import xbmc
import xbmcgui

import motion

CONTAINER_ID = 9000


class ShowcaseWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.movies = kwargs.pop('movies', [])
        self.cache = kwargs.pop('cache', None)
        self.motion_enabled = kwargs.pop('motion_enabled', True)
        self.focus_imdb = kwargs.pop('focus_imdb', '')
        super().__init__(*args, **kwargs)
        self.alive = True
        self._rendering = set()

    def onInit(self):
        container = self.getControl(CONTAINER_ID)
        container.reset()
        items = []
        focus_idx = 0
        for i, m in enumerate(self.movies):
            li = xbmcgui.ListItem(label=m['title'])
            li.setArt(m['art'])
            li.setProperty('imdb', m['imdb'])
            items.append(li)
            if m['imdb'] == self.focus_imdb:
                focus_idx = i
        container.addItems(items)
        if items:
            container.selectItem(focus_idx)
        if self.motion_enabled:
            threading.Thread(target=self._motion_monitor,
                             daemon=True).start()

    def _motion_monitor(self):
        while self.alive:
            try:
                container = self.getControl(CONTAINER_ID)
                item = container.getSelectedItem()
                if item is not None:
                    imdb = item.getProperty('imdb')
                    art = self.cache.get(imdb) if self.cache else {}
                    if imdb and 'animatedposter' not in art \
                            and imdb not in self._rendering:
                        movie = next((m for m in self.movies
                                      if m['imdb'] == imdb), None)
                        poster = (movie or {}).get('poster')
                        if poster:
                            self._rendering.add(imdb)
                            threading.Thread(
                                target=self._render_motion,
                                args=(imdb, poster, item),
                                daemon=True).start()
            except Exception:
                pass
            xbmc.sleep(1500)

    def _render_motion(self, imdb, poster_url, item):
        dest = os.path.join(self.cache.files,
                            '%s_animatedposter.gif' % imdb)
        made = motion.ken_burns(poster_url, dest, width=motion.POSTER_W)
        self._rendering.discard(imdb)
        if made:
            self.cache.set_local(imdb, 'animatedposter', made,
                                 source='motion')
            try:
                item.setArt({'animatedposter': made})
            except Exception:
                pass

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):  # back / previous menu
            self.alive = False
            self.close()
        else:
            super().onAction(action)
