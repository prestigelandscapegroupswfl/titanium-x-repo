#!/usr/bin/env python3
"""Titanium X prototype — Diagnostics window."""
import xbmcgui


class DiagnosticsWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.lines = kwargs.pop('lines', [])
        super().__init__(*args, **kwargs)

    def onInit(self):
        box = self.getControl(100)
        box.setText('\n'.join(self.lines))

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()
        else:
            super().onAction(action)
