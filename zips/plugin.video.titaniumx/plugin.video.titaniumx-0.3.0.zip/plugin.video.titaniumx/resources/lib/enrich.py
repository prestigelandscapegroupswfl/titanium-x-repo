#!/usr/bin/env python3
"""Titanium X prototype — enrichment orchestration (pure Python).

For each catalog movie: start from the keyless Cinemeta base art,
layer fanart.tv and TMDb enrichment on top, persist to the cache,
and return the final Titanium X artwork dict. Cache hits skip the
network entirely. User overrides (in the cache DB) always win.
"""
import providers

BASE_KEYS = ('poster', 'fanart', 'clearlogo')


def enrich_movie(movie, cache, fanart_key='', tmdb_key='',
                 repo_urls=()):
    imdb = movie['imdb']
    cached = cache.get(imdb)
    art = {k: movie[k] for k in BASE_KEYS if movie.get(k)}
    if cached:
        art.update(cached)
        return art
    if not art.get('poster') or not art.get('fanart'):
        # Imported listings may arrive without artwork — fill the
        # base set keylessly from Cinemeta meta by IMDb ID.
        meta = providers.cinemeta_meta(
            imdb, movie.get('media_type', 'movie'))
        for k, v in meta.items():
            art.setdefault(k, v) if v else None
    merged = dict(art)
    repo = providers.repo_artwork(imdb, movie.get('tmdb'), repo_urls)
    for key, url in repo.items():
        # Repository artwork outranks the keyless base (registry
        # order: repo above fanart.tv/TMDb/Cinemeta).
        merged[key] = url
    fa = providers.fanarttv_movie(imdb, fanart_key)
    for key, url in fa.items():
        # fanart.tv clearlogo/poster alternates upgrade the base,
        # everything else fills its own slot.
        if key in ('clearlogo',) or key not in merged:
            merged[key] = url
    td = providers.tmdb_images(movie.get('tmdb'), tmdb_key)
    for key, url in td.items():
        if key not in merged:
            merged[key] = url
    cache.put(imdb, merged, source='enrich')
    merged.update(cache.get(imdb))  # re-apply overrides
    return merged


def enrich_catalog(cache, fanart_key='', tmdb_key='', limit=20,
                   repo_urls=()):
    movies = providers.cinemeta_popular(limit)
    out = []
    for movie in movies:
        movie = dict(movie)
        movie['art'] = enrich_movie(movie, cache, fanart_key, tmdb_key,
                                    repo_urls)
        out.append(movie)
    return out


def enrich_items(items, cache, fanart_key='', tmdb_key='',
                 repo_urls=()):
    """Enrich arbitrary catalog items (Golden folders, series) with
    the same artwork pass as native listings. Items need imdb/tmdb/
    poster/fanart keys; enrichment is best-effort per item."""
    out = []
    for item in items:
        item = dict(item)
        if item.get('media_type') == 'series' and item.get('tmdb') \
                and tmdb_key and fanart_key:
            # Series: bridge TMDb -> TVDb, then fanart.tv show art
            # (true characterart lives on the TV side).
            ids = providers.tmdb_external_ids(item['tmdb'], tmdb_key)
            if ids.get('tvdb'):
                show_art = providers.fanarttv_show(ids['tvdb'],
                                                   fanart_key)
                if show_art:
                    item.setdefault('art', {})
                    merged = dict(item.get('art') or {})
                    for k, v in show_art.items():
                        merged.setdefault(k, v)
                    item['art'] = merged
                    out.append(item)
                    continue
        if item.get('imdb'):
            probe = {'imdb': item['imdb'], 'tmdb': item.get('tmdb'),
                     'poster': item.get('poster', ''),
                     'fanart': item.get('fanart', ''),
                     'clearlogo': item.get('clearlogo', '')}
            item['art'] = enrich_movie(probe, cache, fanart_key, tmdb_key,
                                       repo_urls)
        else:
            item['art'] = {k: item[k] for k in ('poster', 'fanart')
                           if item.get(k)}
        out.append(item)
    return out
