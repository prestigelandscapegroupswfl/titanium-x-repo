#!/usr/bin/env python3
"""Titanium X framework — bulk artwork jobs (pure Python).

The logic behind the Downloader Pro dashboard jobs, kept Kodi-free
so it is unit-testable: which titles are missing which artwork keys,
and a cancellable batch pass that enriches only what is missing.
The Kodi UI supplies progress/cancel callbacks.
"""

DEFAULT_KEYS = ('discart', 'keyart', 'characterart', 'clearart',
                'poster2', 'clearlogo2', 'banner', 'landscape')


def missing_report(movies, keys=DEFAULT_KEYS):
    """{imdb: [missing keys]} for every enriched movie dict."""
    report = {}
    for m in movies:
        art = m.get('art') or {}
        missing = [k for k in keys if not art.get(k)]
        if missing:
            report[m['imdb']] = missing
    return report


def download_missing(items, cache, fanart_key='', tmdb_key='',
                     keys=DEFAULT_KEYS, progress=None, cancelled=None):
    """Enrich items that are missing artwork keys.

    items: raw catalog dicts (imdb/tmdb/poster/fanart/...).
    progress(done, total, title) and cancelled() -> bool are
    optional UI callbacks. Returns stats dict. Locked keys are
    respected by the cache layer (refresh never replaces them).
    """
    from . import enrich
    stats = {'processed': 0, 'improved': 0, 'cancelled': False}
    total = len(items)
    for i, item in enumerate(items):
        if cancelled and cancelled():
            stats['cancelled'] = True
            break
        if progress:
            progress(i, total, item.get('title', ''))
        before = cache.get(item['imdb'])
        missing_before = [k for k in keys if not before.get(k)]
        if missing_before:
            # Force a fresh enrichment pass for this title.
            cache.db.execute('DELETE FROM artwork WHERE imdb=?',
                             (item['imdb'],))
            cache.db.commit()
            enrich.enrich_movie(item, cache, fanart_key, tmdb_key)
            after = cache.get(item['imdb'])
            if any(after.get(k) for k in missing_before):
                stats['improved'] += 1
        stats['processed'] += 1
    if progress:
        progress(total, total, '')
    return stats
