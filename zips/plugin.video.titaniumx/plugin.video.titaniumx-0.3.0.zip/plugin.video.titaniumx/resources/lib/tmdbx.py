#!/usr/bin/env python3
"""Titanium X catalog client — TMDb discovery sections.

Uses the user's own TMDb API key (v3). Every function returns
normalised items {imdb, tmdb, title, year} ready for the Artwork
Engine. Without a key, callers fall back to keyless sources."""
import json
import urllib.parse
import urllib.request

API = 'https://api.themoviedb.org/3'
IMG = 'https://image.tmdb.org/t/p/original'


def _get(path, key, **params):
    params['api_key'] = key
    url = '%s%s?%s' % (API, path, urllib.parse.urlencode(params))
    req = urllib.request.Request(url, headers={'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode('utf-8'))


def _norm(rows, media):
    out = []
    for r in rows or ():
        out.append({
            'imdb': r.get('imdb_id') or '',
            'tmdb': r.get('id'),
            'title': r.get('title') or r.get('name') or '',
            'year': (r.get('release_date') or r.get('first_air_date')
                     or '')[:4],
            'media': media,
            'poster_path': r.get('poster_path') or '',
            'backdrop_path': r.get('backdrop_path') or '',
        })
    return out


def section(name, key, page=1):
    """Discovery sections served straight from TMDb."""
    routes = {
        'trending_movies': ('/trending/movie/week', 'movie'),
        'popular_movies': ('/movie/popular', 'movie'),
        'new_releases': ('/movie/now_playing', 'movie'),
        'upcoming': ('/movie/upcoming', 'movie'),
        'top_rated': ('/movie/top_rated', 'movie'),
        'trending_tv': ('/trending/tv/week', 'tv'),
        'popular_tv': ('/tv/popular', 'tv'),
        'new_episodes': ('/tv/on_the_air', 'tv'),
        'top_rated_tv': ('/tv/top_rated', 'tv'),
    }
    if name in routes:
        path, media = routes[name]
        return _norm(_get(path, key, page=page).get('results'), media)
    discover = {
        'anime': ('tv', {'with_genres': 16, 'with_original_language': 'ja'}),
        'documentaries': ('movie', {'with_genres': 99}),
        'kids_family': ('movie', {'with_genres': 10751,
                                   'certification_country': 'US',
                                   'certification.lte': 'PG'}),
    }
    if name in discover:
        media, extra = discover[name]
        return _norm(_get('/discover/%s' % media, key, page=page,
                          **extra).get('results'), media)
    if name.startswith('genre_'):
        gid = name.split('_', 1)[1]
        return _norm(_get('/discover/movie', key, page=page,
                          with_genres=gid).get('results'), 'movie')
    if name.startswith('decade_'):
        decade = int(name.split('_', 1)[1])
        return _norm(_get('/discover/movie', key, page=page, **{
            'primary_release_date.gte': '%d-01-01' % decade,
            'primary_release_date.lte': '%d-12-31' % (decade + 9),
            'sort_by': 'vote_count.desc'}).get('results'), 'movie')
    return []


GENRES = [(28, 'Action'), (12, 'Adventure'), (16, 'Animation'),
          (35, 'Comedy'), (80, 'Crime'), (99, 'Documentary'),
          (18, 'Drama'), (10751, 'Family'), (14, 'Fantasy'),
          (27, 'Horror'), (9648, 'Mystery'), (10749, 'Romance'),
          (878, 'Science Fiction'), (53, 'Thriller'), (10752, 'War'),
          (37, 'Western')]

DECADES = [1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020]

SECTIONS = [
    ('trending_movies', 'Trending Movies'),
    ('popular_movies', 'Popular Movies'),
    ('new_releases', 'New Releases'),
    ('upcoming', 'Upcoming Movies'),
    ('top_rated', 'Top Rated Movies'),
    ('trending_tv', 'Trending TV Shows'),
    ('popular_tv', 'Popular TV Shows'),
    ('new_episodes', 'New Episodes'),
    ('top_rated_tv', 'Top Rated TV'),
    ('collections', 'Movie Collections'),
    ('genres', 'Genres'),
    ('decades', 'Decades'),
    ('anime', 'Anime'),
    ('documentaries', 'Documentaries'),
    ('kids_family', 'Kids and Family'),
    ('watchlist', 'My Watchlist'),
    ('continue_watching', 'Continue Watching'),
    ('recently_watched', 'Recently Watched'),
    ('recommended', 'Recommended for You'),
    ('search', 'Universal Search'),
]
