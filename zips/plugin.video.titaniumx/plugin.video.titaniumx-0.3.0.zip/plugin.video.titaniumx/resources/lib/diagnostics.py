#!/usr/bin/env python3
"""Titanium X prototype — diagnostics report builder (pure Python).

Reports artwork sources, per-key coverage, cache usage, missing
artwork, catalog status and animation support. Shown in the
Diagnostics window; also unit-testable without Kodi.
"""
import os

KEYS = ('poster', 'fanart', 'clearlogo', 'clearart', 'characterart',
        'keyart', 'keyart2', 'poster2', 'discart', 'animatedposter',
        'animatedfanart', 'banner', 'landscape')


def build_report(movies, cache, catalog_status):
    lines = ['[B]Titanium X Diagnostics[/B]', '']
    lines.append('Catalogs:')
    for name, status in catalog_status.items():
        lines.append('  %s: %s' % (name, status))
    lines.append('')
    lines.append('Artwork coverage across %d sampled titles:'
                 % len(movies))
    for key in KEYS:
        have = sum(1 for m in movies if m.get('art', {}).get(key))
        if have:
            lines.append('  %s: %d/%d' % (key, have, len(movies)))
    lines.append('')
    missing = [(m['title'], [k for k in ('discart', 'keyart',
                                         'characterart', 'clearart')
                             if not m.get('art', {}).get(k)])
               for m in movies]
    lacking = [(t, ks) for t, ks in missing if ks]
    lines.append('Titles missing extended artwork: %d' % len(lacking))
    for title, keys in lacking[:8]:
        lines.append('  %s — missing %s' % (title, ', '.join(keys)))
    if lacking:
        lines.append('  (Extended art needs a free fanart.tv / TMDb '
                     'key in Settings.)')
    lines.append('')
    stats = cache.stats()
    files = [f for f in os.listdir(cache.files)] \
        if os.path.isdir(cache.files) else []
    total = sum(os.path.getsize(os.path.join(cache.files, f))
                for f in files)
    gifs = [f for f in files if f.endswith('.gif')]
    lines.append('Cache: %d titles indexed, %d local files, %.1f MB'
                 % (stats['titles'], len(files), total / 1e6))
    lines.append('Animation: %d locally cached animated files '
                 '(local files animate in Kodi; remote GIFs show '
                 'their first frame)' % len(gifs))
    lines.append('Library: prototype never writes to the Kodi '
                 'library — listings are dynamic only.')
    return lines
