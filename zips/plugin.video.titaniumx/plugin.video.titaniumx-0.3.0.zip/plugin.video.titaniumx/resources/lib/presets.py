#!/usr/bin/env python3
"""Titanium X Motion Studio — genre motion presets (data + rules).

Each preset names a Motion Engine effect, its speed/intensity and
which artwork slot it targets. Native skin effects (zoom/pan/glow/
borders/disc spin) are applied by the skin at display time; rendered
effects (kenburns) are produced by motion.py into the local cache.
Weather/particle looks are pre-rendered transparent overlays served
from artwork repositories — never generated on the device.
"""

# effect: 'kenburns' (rendered) or a native skin effect name.
PRESETS = {
    'Action':      {'effect': 'kenburns', 'speed': 1.2, 'intensity': 0.7, 'slot': 'fanart'},
    'Adventure':   {'effect': 'kenburns', 'speed': 1.0, 'intensity': 0.6, 'slot': 'fanart'},
    'Animation':   {'effect': 'kenburns', 'speed': 1.1, 'intensity': 0.5, 'slot': 'poster'},
    'Comedy':      {'effect': 'kenburns', 'speed': 1.0, 'intensity': 0.4, 'slot': 'poster'},
    'Crime':       {'effect': 'kenburns', 'speed': 0.8, 'intensity': 0.5, 'slot': 'fanart'},
    'Documentary': {'effect': 'kenburns', 'speed': 0.7, 'intensity': 0.3, 'slot': 'fanart'},
    'Drama':       {'effect': 'kenburns', 'speed': 0.7, 'intensity': 0.4, 'slot': 'fanart'},
    'Family':      {'effect': 'kenburns', 'speed': 0.9, 'intensity': 0.4, 'slot': 'poster'},
    'Fantasy':     {'effect': 'kenburns', 'speed': 0.9, 'intensity': 0.6, 'slot': 'fanart'},
    'Horror':      {'effect': 'kenburns', 'speed': 0.6, 'intensity': 0.8, 'slot': 'fanart'},
    'Mystery':     {'effect': 'kenburns', 'speed': 0.7, 'intensity': 0.6, 'slot': 'fanart'},
    'Romance':     {'effect': 'kenburns', 'speed': 0.6, 'intensity': 0.3, 'slot': 'fanart'},
    'Sci-Fi':      {'effect': 'kenburns', 'speed': 0.9, 'intensity': 0.6, 'slot': 'fanart'},
    'Science Fiction': {'effect': 'kenburns', 'speed': 0.9, 'intensity': 0.6, 'slot': 'fanart'},
    'Thriller':    {'effect': 'kenburns', 'speed': 0.8, 'intensity': 0.7, 'slot': 'fanart'},
    'War':         {'effect': 'kenburns', 'speed': 0.8, 'intensity': 0.6, 'slot': 'fanart'},
    'Western':     {'effect': 'kenburns', 'speed': 0.7, 'intensity': 0.5, 'slot': 'fanart'},
}

DEFAULT = {'effect': 'kenburns', 'speed': 1.0, 'intensity': 0.5,
           'slot': 'fanart'}

# Pre-rendered overlay families (repository-served, transparent).
OVERLAYS = ('particles', 'rain', 'snow', 'fog', 'smoke', 'embers',
            'neon-pulse')


def preset_for(genres):
    """First matching genre preset wins; default otherwise."""
    for genre in genres or ():
        if genre in PRESETS:
            return dict(PRESETS[genre])
    return dict(DEFAULT)


def zoom_for(preset):
    """Map preset intensity (0..1) to a Ken Burns zoom factor."""
    return 1.0 + 0.04 + 0.08 * float(preset.get('intensity', 0.5))
