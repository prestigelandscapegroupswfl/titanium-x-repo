#!/usr/bin/env python3
"""Titanium X — dynamic catalog provider (v0.3.0).

Streaming-first: every section is a live catalog; nothing is added
to the Kodi library. Sections are served by the TMDb discovery
client (user's own key), with keyless fallbacks (Cinemeta, Golden
Catalogue/MDBList) so discovery works before any key is added.
Account sections (Trakt) activate when the user connects Trakt in
Settings. Every listing passes through the Artwork Engine, which
stamps the full Titanium X art set onto each item. Selecting a
title opens its provider page: information, trailer, watchlist,
and the user's authorized playback providers by priority."""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]

sys.path.append(os.path.join(ADDON.getAddonInfo('path'), 'resources',
                             'lib'))
import providers  # noqa: E402
import enrich  # noqa: E402
import golden  # noqa: E402
import diagnostics  # noqa: E402
import tmdbx  # noqa: E402
from cache import ArtworkCache  # noqa: E402

GOLDEN_URL = ('https://raw.githubusercontent.com/0x8e8fb-p/'
              'nuvio-golden-catalogue/master/data/collections.json')

_cache = None


def get_cache():
    global _cache
    if _cache is None:
        path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        os.makedirs(path, exist_ok=True)
        _cache = ArtworkCache(path)
    return _cache


def keys():
    return (ADDON.getSetting('fanarttv_key'),
            ADDON.getSetting('tmdb_key'))


def repo_urls():
    urls = []
    main = ADDON.getSetting('assets_manifest_url')
    if main:
        urls.append(main)
    extra = ADDON.getSetting('extra_repo_urls')
    urls += [u.strip() for u in extra.split(',') if u.strip()]
    return tuple(urls)


def url(**params):
    return BASE + '?' + urllib.parse.urlencode(params)


_buffer = []


def add_item(item, is_folder=False, context=()):
    li = xbmcgui.ListItem(label=item.get('label') or item.get('title')
                          or '')
    art = dict(item.get('art') or {})
    if art:
        li.setArt(art)
    info = item.get('info') or {}
    if info:
        li.getVideoInfoTag().setTitle(info.get('title', ''))
    if context:
        li.addContextMenuItems(list(context))
    _buffer.append((item.get('url') or url(
        action='providers', imdb=item.get('imdb', ''),
        tmdb=item.get('tmdb', ''), title=item.get('title', ''),
        media=item.get('media', 'movie')), li, is_folder))


def finish():
    global _buffer
    xbmcplugin.addDirectoryItems(HANDLE, _buffer, len(_buffer))
    _buffer = []
    xbmcplugin.endOfDirectory(HANDLE)


def notice_item(label, action='settings'):
    add_item({'label': label, 'url': url(action=action),
              'title': label})
    finish()


def enrich_items(items):
    fanart_key, tmdb_key = keys()
    cache = get_cache()
    ready = []
    for it in items:
        if not it.get('imdb') and it.get('tmdb') and tmdb_key:
            ids = providers.tmdb_external_ids(it['tmdb'], tmdb_key,
                                              it.get('media', 'movie'))
            it['imdb'] = ids.get('imdb', '')
        if not it.get('imdb'):
            it['imdb'] = 'tmdb%s' % it.get('tmdb', '')
        probe = {'imdb': it['imdb'], 'tmdb': it.get('tmdb'),
                 'title': it.get('title', ''), 'year': it.get('year', ''),
                 'media': it.get('media', 'movie')}
        if it.get('poster_path'):
            probe['poster'] = tmdbx.IMG + it['poster_path']
        if it.get('backdrop_path'):
            probe['fanart'] = tmdbx.IMG + it['backdrop_path']
        ready.append(probe)
    enriched = enrich.enrich_items(ready, cache, fanart_key, tmdb_key,
                                   repo_urls=repo_urls())
    out = []
    for probe, src in zip(enriched, items):
        src['art'] = probe.get('art') or {}
        src['label'] = src.get('title', '')
        out.append(src)
    return out


def list_items(items):
    for it in enrich_items(items):
        add_item(it)
    finish()


def root():
    for name, label in tmdbx.SECTIONS:
        add_item({'label': label,
                  'url': url(action='section', name=name),
                  'title': label}, is_folder=True)
    add_item({'label': 'Golden Catalogue',
              'url': url(action='golden'), 'title': 'Golden'},
             is_folder=True)
    add_item({'label': 'Showcase',
              'url': url(action='showcase'), 'title': 'Showcase'},
             is_folder=True)
    add_item({'label': 'Diagnostics',
              'url': url(action='diagnostics'), 'title': 'Diagnostics'})
    add_item({'label': 'Settings',
              'url': url(action='settings'), 'title': 'Settings'})
    finish()


def section(name):
    fanart_key, tmdb_key = keys()
    if name == 'genres':
        for gid, label in tmdbx.GENRES:
            add_item({'label': label,
                      'url': url(action='section',
                                 name='genre_%d' % gid),
                      'title': label}, is_folder=True)
        return finish()
    if name == 'decades':
        for decade in tmdbx.DECADES:
            add_item({'label': '%ds' % decade,
                      'url': url(action='section',
                                 name='decade_%d' % decade),
                      'title': '%ds' % decade}, is_folder=True)
        return finish()
    if name == 'collections':
        return golden_root()
    if name == 'watchlist':
        items = get_cache().watchlist()
        if not items:
            return notice_item('Your watchlist is empty — open any '
                               'title and choose Add to watchlist',
                               'section')
        return list_items([dict(it, media='movie') for it in items])
    if name in ('continue_watching', 'recently_watched', 'recommended'):
        if not ADDON.getSetting('trakt_token'):
            return notice_item(
                'Connect Trakt in Settings to activate this section — '
                'discovery catalogs work without it')
        return notice_item('Trakt is connected; sync runs in the '
                           'background service', 'section')
    if name == 'search':
        kb = xbmc.Keyboard('', 'Universal Search')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            return search_results(kb.getText())
        return finish()
    if tmdb_key:
        try:
            items = tmdbx.section(name, tmdb_key)
        except Exception:
            items = []
        if items:
            return list_items(items)
    # Keyless fallbacks
    if name in ('popular_movies', 'trending_movies'):
        return list_items(providers.cinemeta_popular(20))
    if name in ('popular_tv', 'trending_tv'):
        return list_items(providers.cinemeta_series(20))
    if name == 'top_rated':
        pack = golden.load_pack(GOLDEN_URL)
        for coll in pack:
            for folder in coll['folders']:
                if '250' in folder['title']:
                    items = golden.execute_folder(folder, tmdb_key)
                    if items:
                        return list_items(items)
    return notice_item('Add your free TMDb API key in Settings to '
                       'unlock this catalog — discovery sections '
                       'marked Popular/Trending work without one')


def search_results(query):
    fanart_key, tmdb_key = keys()
    if not tmdb_key:
        return notice_item('Universal Search needs a TMDb API key — '
                           'add your free key in Settings')
    data = tmdbx._get('/search/multi', tmdb_key, query=query)
    items = []
    for r in data.get('results', []):
        media = r.get('media_type')
        if media not in ('movie', 'tv'):
            continue
        items.append({'imdb': '', 'tmdb': r.get('id'),
                      'title': r.get('title') or r.get('name') or '',
                      'year': (r.get('release_date')
                               or r.get('first_air_date') or '')[:4],
                      'media': media,
                      'poster_path': r.get('poster_path') or '',
                      'backdrop_path': r.get('backdrop_path') or ''})
    return list_items(items)


def golden_root():
    pack = golden.load_pack(GOLDEN_URL)
    for coll in pack:
        add_item({'label': coll['title'],
                  'url': url(action='golden_collection',
                             cid=coll['id']),
                  'title': coll['title']}, is_folder=True)
    finish()


def golden_collection(cid):
    pack = golden.load_pack(GOLDEN_URL)
    for coll in pack:
        if coll['id'] == cid:
            for folder in coll['folders']:
                add_item({'label': folder['title'],
                          'url': url(action='golden_folder', cid=cid,
                                     fid=folder['id']),
                          'title': folder['title']}, is_folder=True)
    finish()


def golden_folder(cid, fid):
    fanart_key, tmdb_key = keys()
    pack = golden.load_pack(GOLDEN_URL)
    for coll in pack:
        if coll['id'] == cid:
            for folder in coll['folders']:
                if folder['id'] == fid:
                    items = golden.execute_folder(folder, tmdb_key)
                    return list_items(items)
    finish()


def providers_page(imdb, tmdb, title, media):
    fanart_key, tmdb_key = keys()
    probe = {'imdb': imdb, 'tmdb': tmdb or None, 'title': title,
             'media': media}
    enriched = enrich.enrich_items([probe], get_cache(), fanart_key,
                                   tmdb_key, repo_urls=repo_urls())
    art = enriched[0].get('art') or {}
    entries = [
        ('Information', url(action='info', imdb=imdb, tmdb=tmdb,
                            title=title, media=media)),
        ('Watch trailer', url(action='trailer', title=title)),
        ('Play with Torus', url(action='play', provider='torus',
                                imdb=imdb, media=media)),
        ('Play with TMDb Helper', url(action='play',
                                      provider='tmdbhelper',
                                      imdb=imdb, tmdb=tmdb,
                                      media=media)),
        ('Add to watchlist', url(action='watchlist_add', imdb=imdb,
                                 title=title)),
        ('Open in Artwork Downloader Pro',
         url(action='artwork_pro')),
    ]
    for label, target in entries:
        add_item({'label': label, 'url': target, 'title': title,
                  'art': art})
    finish()


def play(provider_name, imdb, tmdb, media):
    if provider_name == 'torus':
        target = ('plugin://plugin.video.torus/?action=play&imdb=%s'
                  '&mtype=%s' % (imdb, media))
    else:
        target = ('plugin://plugin.video.themoviedb.helper/?action=play'
                  '&imdb_id=%s&tmdb_id=%s' % (imdb, tmdb))
    xbmc.executebuiltin('PlayMedia(%s)' % target)


def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
    action = params.get('action', 'root')
    if action == 'root':
        root()
    elif action == 'section':
        section(params.get('name', ''))
    elif action == 'movies':
        section('popular_movies')
    elif action == 'series':
        section('popular_tv')
    elif action == 'golden':
        golden_root()
    elif action == 'golden_collection':
        golden_collection(params.get('cid', ''))
    elif action == 'golden_folder':
        golden_folder(params.get('cid', ''), params.get('fid', ''))
    elif action == 'providers':
        providers_page(params.get('imdb', ''), params.get('tmdb', ''),
                       params.get('title', ''),
                       params.get('media', 'movie'))
    elif action == 'play':
        play(params.get('provider', 'torus'), params.get('imdb', ''),
             params.get('tmdb', ''), params.get('media', 'movie'))
    elif action == 'trailer':
        title = params.get('title', '')
        xbmc.executebuiltin(
            'PlayMedia(plugin://plugin.video.youtube/search/'
            '?q=%s)' % urllib.parse.quote(title + ' trailer'))
    elif action == 'watchlist_add':
        get_cache().watchlist_add(params.get('imdb', ''),
                                  params.get('title', ''))
        xbmcgui.Dialog().notification('Titanium X',
                                      'Added to watchlist', time=3000)
    elif action == 'artwork_pro':
        xbmc.executebuiltin('RunScript(script.titaniumx.artwork)')
    elif action == 'info':
        xbmc.executebuiltin('ActivateWindow(movieinformation)')
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'showcase':
        win = ShowcaseWindow('TitaniumShowcase.xml',
                             ADDON.getAddonInfo('path'), 'Default')
        win.doModal()
    elif action == 'diagnostics':
        fanart_key, tmdb_key = keys()
        cache = get_cache()
        movies = enrich.enrich_catalog(cache, fanart_key, tmdb_key,
                                       limit=20, repo_urls=repo_urls())
        lines = diagnostics.build_report(movies, cache, {})
        xbmcgui.Dialog().textviewer('Titanium X — Diagnostics',
                                    '\n'.join(lines))
    else:
        root()


_BaseWindow = getattr(xbmcgui, 'WindowXML', None) or \
    xbmcgui.WindowXMLDialog


class ShowcaseWindow(_BaseWindow):
    pass


if __name__ == '__main__':
    main()
