#!/usr/bin/env python3
"""Titanium X Wizard — UI (Phase 3 initial).

Menu: Check for updates · Back up Titanium X · Restore backup ·
Clean artwork cache. Destructive actions always confirm first;
factory reset is intentionally NOT in this build — it arrives only
with the full confirmation flow from the spec."""
import os
import sys
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
sys.path.insert(0, os.path.join(ADDON.getAddonInfo('path'),
                                'resources', 'lib'))
import core  # noqa: E402

REPO_ADDONS_XML = ('https://raw.githubusercontent.com/'
                   'prestigelandscapegroupswfl/titanium-x-repo/'
                   'master/addons.xml')


def profiles_root():
    return xbmc.translatePath('special://profile/addon_data/')


def backups_dir():
    path = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')),
                        'backups')
    os.makedirs(path, exist_ok=True)
    return path


def check_updates():
    installed = {}
    for addon_id in core.TX_ADDONS + ('program.titaniumx.wizard',):
        try:
            installed[addon_id] = xbmcaddon.Addon(addon_id) \
                .getAddonInfo('version')
        except Exception:
            pass
    try:
        with urllib.request.urlopen(REPO_ADDONS_XML, timeout=30) as resp:
            xml_text = resp.read().decode('utf-8')
    except Exception:
        xbmcgui.Dialog().notification('Titanium X Wizard',
                                      'Repository unreachable',
                                      time=5000)
        return
    updates = core.check_updates(installed, xml_text)
    if not updates:
        xbmcgui.Dialog().ok('Titanium X Wizard',
                            'Everything is up to date.')
        return
    lines = ['%s: %s -> %s' % (u['id'], u['installed'], u['available'])
             for u in updates]
    xbmcgui.Dialog().ok('Titanium X Wizard',
                        'Updates available (install via the '
                        'Titanium X repository):\n' + '\n'.join(lines))


def do_backup():
    dialog = xbmcgui.Dialog()
    shared = dialog.yesno(
        'Titanium X Wizard',
        'Create a SHARED backup? Shared backups exclude API keys '
        'and credentials. Choose No for a full local backup.')
    import time
    name = 'titaniumx-backup-%s.zip' % time.strftime('%Y%m%d-%H%M%S')
    dest = os.path.join(backups_dir(), name)
    manifest = core.create_backup(profiles_root(), dest,
                                  exclude_credentials=bool(shared))
    dialog.ok('Titanium X Wizard',
              'Backup saved: %s\n%d files, credentials %s.'
              % (name, len(manifest['files']),
                 'excluded' if shared else 'included (local only)'))


def do_restore():
    dialog = xbmcgui.Dialog()
    files = sorted(f for f in os.listdir(backups_dir())
                   if f.endswith('.zip'))
    if not files:
        dialog.ok('Titanium X Wizard', 'No backups found.')
        return
    pick = dialog.select('Restore which backup?', files)
    if pick < 0:
        return
    if not dialog.yesno('Titanium X Wizard',
                        'Restore %s? Current Titanium X settings '
                        'will be overwritten.' % files[pick]):
        return
    count = core.restore_backup(os.path.join(backups_dir(),
                                             files[pick]),
                                profiles_root())
    dialog.ok('Titanium X Wizard', 'Restored %d files.' % count)


def clean_cache():
    dialog = xbmcgui.Dialog()
    cache_files = xbmc.translatePath(
        'special://profile/addon_data/script.titaniumx.artwork/files/')
    if not os.path.isdir(cache_files):
        dialog.ok('Titanium X Wizard', 'No artwork cache found.')
        return
    names = os.listdir(cache_files)
    total = sum(os.path.getsize(os.path.join(cache_files, n))
                for n in names)
    if not dialog.yesno('Titanium X Wizard',
                        'Delete %d cached artwork files (%.1f MB)? '
                        'Artwork re-downloads on demand. Your chosen '
                        'artwork and settings are NOT touched.'
                        % (len(names), total / 1e6)):
        return
    for n in names:
        try:
            os.remove(os.path.join(cache_files, n))
        except OSError:
            pass
    dialog.ok('Titanium X Wizard', 'Artwork cache cleaned.')


def install_build():
    import json as _json
    dialog = xbmcgui.Dialog()
    names = list(core.PROFILES)
    pick = dialog.select('Install Titanium X — choose your device '
                         'profile', names)
    if pick < 0:
        return
    plan = core.install_plan(names[pick])
    progress = xbmcgui.DialogProgress()
    progress.create('Titanium X Wizard', 'Installing Titanium X…')
    for i, addon_id in enumerate(plan):
        if progress.iscanceled():
            break
        progress.update(int(i * 100 / len(plan)),
                        'Installing %s' % addon_id)
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
        xbmc.sleep(1500)
    progress.close()
    if dialog.yesno('Titanium X Wizard',
                    'Switch to the Titanium X skin now?'):
        xbmc.executeJSONRPC(_json.dumps({
            'jsonrpc': '2.0', 'method': 'Settings.SetSettingValue',
            'params': {'setting': 'lookandfeel.skin',
                       'value': 'skin.titaniumx'}, 'id': 1}))


def install_helpers():
    progress = xbmcgui.DialogProgress()
    progress.create('Titanium X Wizard', 'Installing helper pack…')
    for i, addon_id in enumerate(core.HELPERS):
        if progress.iscanceled():
            break
        progress.update(int(i * 100 / len(core.HELPERS)),
                        'Installing %s' % addon_id)
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
        xbmc.sleep(1200)
    progress.close()


def main():
    choice = xbmcgui.Dialog().select(
        'Titanium X Wizard',
        ['Install Titanium X build (one-click)',
         'Install skin helper pack',
         'Check for updates', 'Back up Titanium X', 'Restore backup',
         'Clean artwork cache'])
    (install_build, install_helpers, check_updates, do_backup,
     do_restore, clean_cache)[choice]() \
        if choice >= 0 else None


if __name__ == '__main__':
    main()
