#!/usr/bin/env python3
"""Titanium X Wizard — core engine (pure Python, unit-tested).

Backup/restore of the Titanium X ecosystem state and repository
version checks. Safety rules (Jay's spec):
  * Backups NEVER log or list credential VALUES — manifests record
    file names and sizes only.
  * exclude_credentials=True strips API-key settings from the
    settings copies inside the backup (for shared backups).
  * Nothing is deleted by backup/restore; restore overwrites only
    the files listed in the backup manifest.
"""
import json
import os
import re
import time
import zipfile

CREDENTIAL_SETTINGS = ('fanarttv_key', 'tmdb_key', 'api_key', 'password',
                       'token')
TX_ADDONS = ('script.titaniumx.artwork',
             'script.module.titaniumx.artwork',
             'service.titaniumx.artwork',
             'plugin.video.titaniumx')


def _strip_credentials(xml_text):
    for name in CREDENTIAL_SETTINGS:
        xml_text = re.sub(
            r'(<setting id="%s"[^>]*>)[^<]*(</setting>)' % name,
            r'\1\2', xml_text)
        xml_text = re.sub(
            r'(<setting id="%s"[^>]*/>)' % name, r'\1', xml_text)
    return xml_text


def create_backup(profile_root, dest_zip, include_cache=True,
                  exclude_credentials=False):
    """profile_root: folder holding per-addon profile dirs named by
    addon id. Returns the manifest dict written into the zip."""
    manifest = {'created': time.strftime('%Y-%m-%dT%H:%M:%S'),
                'files': [], 'exclude_credentials': exclude_credentials}
    with zipfile.ZipFile(dest_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        for addon_id in TX_ADDONS:
            src_dir = os.path.join(profile_root, addon_id)
            if not os.path.isdir(src_dir):
                continue
            for dirpath, _dirs, files in os.walk(src_dir):
                for name in files:
                    if name.endswith('.db') and not include_cache:
                        continue
                    full = os.path.join(dirpath, name)
                    arc = os.path.relpath(full, profile_root)
                    data = None
                    if exclude_credentials and name == 'settings.xml':
                        with open(full, encoding='utf-8',
                                  errors='replace') as fh:
                            data = _strip_credentials(fh.read())
                    if data is not None:
                        z.writestr(arc, data)
                    else:
                        z.write(full, arc)
                    manifest['files'].append(
                        {'path': arc, 'bytes': os.path.getsize(full)})
        z.writestr('manifest.json', json.dumps(manifest, indent=1))
    return manifest


def restore_backup(zip_path, profile_root):
    """Restore exactly the files in the backup. Returns file count.
    Raises ValueError on a zip without a Titanium X manifest."""
    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
        if 'manifest.json' not in names:
            raise ValueError('not a Titanium X backup (no manifest)')
        manifest = json.loads(z.read('manifest.json').decode('utf-8'))
        count = 0
        for entry in manifest['files']:
            arc = entry['path']
            if arc not in names:
                continue
            dest = os.path.join(profile_root, arc)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, 'wb') as fh:
                fh.write(z.read(arc))
            count += 1
    return count


def parse_version(text):
    return tuple(int(p) for p in re.findall(r'\d+', text or '0')[:3])


def check_updates(installed, addons_xml_text):
    """installed: {addon_id: version}. Returns [{id, installed,
    available}] for add-ons with a newer version in the repo."""
    available = dict(re.findall(
        r'<addon id="([^"]+)"[^>]*version="([^"]+)"', addons_xml_text))
    out = []
    for aid, ver in installed.items():
        if aid in available and \
                parse_version(available[aid]) > parse_version(ver):
            out.append({'id': aid, 'installed': ver,
                        'available': available[aid]})
    return out


# One-click build installation profiles (Jay's spec: device profiles
# in the Wizard). Order matters: engine first, skin last so Kodi's
# switch prompt arrives after everything else is in place.
PROFILES = {
    'Lite': ['script.module.titaniumx.artwork',
             'service.titaniumx.artwork',
             'plugin.video.titaniumx',
             'skin.titaniumx'],
    'Balanced': ['script.module.titaniumx.artwork',
                 'service.titaniumx.artwork',
                 'plugin.video.titaniumx',
                 'script.titaniumx.artwork',
                 'script.titaniumx.providers',
                 'script.titaniumx.setup',
                 'program.titaniumx.wizard',
                 'skin.titaniumx'],
    'Ultimate': ['script.module.titaniumx.artwork',
                 'service.titaniumx.artwork',
                 'plugin.video.themoviedb.helper',
                 'plugin.video.youtube',
                 'service.titaniumx.artwork',
                 'plugin.video.titaniumx',
                 'script.titaniumx.artwork',
                 'script.titaniumx.providers',
                 'script.titaniumx.setup',
                 'program.titaniumx.wizard',
                 'program.titaniumx.buildcreator',
                 'script.skinshortcuts', 'script.embuary.helper',
                 'script.embuary.info',
                 'script.image.resource.select',
                 'script.globalsearch',
                 'script.skin.helper.colorpicker',
                 'skin.titaniumx'],
}


# Skin-helper pack — every entry VERIFIED present in the official
# Kodi 22 (Piers) repository, 2026-11-24. NOTE: the classic
# script.skin.helper.service is NOT carried for Piers; Titanium X
# does not depend on it (the Artwork Engine covers that role).
HELPERS = ['script.skinshortcuts', 'script.embuary.helper',
           'script.embuary.info', 'script.image.resource.select',
           'script.globalsearch', 'script.skin.helper.colorpicker',
           'plugin.video.themoviedb.helper', 'plugin.video.youtube']


def install_plan(profile):
    if profile not in PROFILES:
        raise ValueError('unknown profile: %s' % profile)
    return list(PROFILES[profile])
