#!/usr/bin/env python3
"""Titanium X Build Creator Pro — core (pure Python, unit-tested).

Assembles a build definition (base skin, add-ons, collections,
artwork packs, theme, performance preset) into a build manifest,
and exports an installable build ZIP containing the manifest plus
the add-on ZIPs. Credentials are structurally excluded: the manifest
schema has no settings/credential fields at all, and export refuses
any file whose name suggests credentials."""
import json
import os
import time
import zipfile

FORBIDDEN = ('settings.xml', 'password', 'token', 'credential',
             'secret', '.key')

SCHEMA_KEYS = ('name', 'version', 'skin', 'addons', 'collections',
               'artwork_packs', 'theme', 'preset', 'default_views')


def make_manifest(build):
    missing = [k for k in ('name', 'version') if not build.get(k)]
    if missing:
        raise ValueError('build is missing: %s' % ', '.join(missing))
    manifest = {k: build.get(k) for k in SCHEMA_KEYS}
    manifest['created'] = time.strftime('%Y-%m-%dT%H:%M:%S')
    manifest['generator'] = 'Titanium X Build Creator Pro'
    return manifest


def export_build(build, addon_zips, dest_zip):
    """addon_zips: {addon_id: path-to-zip}. Returns the manifest."""
    manifest = make_manifest(build)
    with zipfile.ZipFile(dest_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('build.json', json.dumps(manifest, indent=1))
        for addon_id, path in sorted(addon_zips.items()):
            name = os.path.basename(path)
            if any(f in name.lower() for f in FORBIDDEN):
                raise ValueError('refusing credential-like file: %s'
                                 % name)
            z.write(path, 'addons/%s' % name)
    return manifest
