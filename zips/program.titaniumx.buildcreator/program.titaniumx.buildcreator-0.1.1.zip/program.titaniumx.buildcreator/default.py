#!/usr/bin/env python3
"""Titanium X Build Creator Pro — UI (initial).

Flow: name the build -> pick theme + preset -> export a build ZIP
(manifest + the Titanium X add-on ZIPs found in the local repository
cache folder) into the addon's builds folder."""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
sys.path.insert(0, os.path.join(ADDON.getAddonInfo('path'),
                                'resources', 'lib'))
import buildcore  # noqa: E402

THEMES = ('Purple Chrome', 'Black Gold', 'Ice Blue', 'Crimson Red')
PRESETS = ('Lite', 'Balanced', 'Ultimate')
TX_ADDONS = ('script.module.titaniumx.artwork',
             'service.titaniumx.artwork', 'script.titaniumx.artwork',
             'plugin.video.titaniumx', 'program.titaniumx.wizard',
             'repository.titaniumx')


def builds_dir():
    path = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')),
                        'builds')
    os.makedirs(path, exist_ok=True)
    return path


def main():
    dialog = xbmcgui.Dialog()
    name = dialog.input('Build name', defaultt='Titanium X Ultimate')
    if not name:
        return
    ti = dialog.select('Theme', list(THEMES))
    if ti < 0:
        return
    theme = THEMES[ti]
    pi = dialog.select('Performance preset', list(PRESETS))
    if pi < 0:
        return
    preset = PRESETS[pi]
    version = dialog.input('Build version', defaultt='1.0.0')
    build = {'name': name, 'version': version or '1.0.0',
             'skin': 'skin.titaniumx', 'addons': list(TX_ADDONS),
             'collections': ['golden'],
             'artwork_packs': ['titanium-x-assets'],
             'theme': theme, 'preset': preset,
             'default_views': {'movies': 'Showcase'}}
    dest = os.path.join(builds_dir(),
                        '%s-%s.zip' % (name.replace(' ', '-').lower(),
                                       build['version']))
    try:
        buildcore.export_build(build, {}, dest)
    except ValueError as exc:
        dialog.ok('Titanium X Build Creator Pro', str(exc))
        return
    dialog.ok('Titanium X Build Creator Pro',
              'Build manifest exported:\n%s\n(Add-on ZIP bundling '
              'arrives with the repository cache integration.)' % dest)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        import traceback
        err = traceback.format_exc()
        xbmc.log('Titanium X Build Creator Pro error:\n' + err,
                 xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().textviewer(
                'Titanium X Build Creator Pro — error', err)
        except Exception:
            pass
