#!/usr/bin/env python3
"""Titanium X Artwork Downloader Pro — main dashboard (Phase 1).

Menu: Enrich popular catalog (demo of the engine) · Diagnostics ·
Settings. The full download dashboard, alternatives browser and
studios arrive in Phases 2-3 per docs/PHASES.md."""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
sys.path.append(xbmc.translatePath(
    'special://home/addons/script.module.titaniumx.artwork/resources/lib'))

from titaniumx import cache as cache_mod  # noqa: E402
from titaniumx import diagnostics, enrich, registry  # noqa: E402


def profile_dir():
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(path, exist_ok=True)
    return path


def show_diagnostics():
    cache = cache_mod.ArtworkCache(profile_dir())
    movies = enrich.enrich_catalog(
        cache, ADDON.getSetting('fanarttv_key'),
        ADDON.getSetting('tmdb_key'), limit=20)
    settings = {'fanarttv_key': ADDON.getSetting('fanarttv_key'),
                'tmdb_key': ADDON.getSetting('tmdb_key')}
    status = {'Providers': ', '.join(
        '%s=%s' % (k, v) for k, v in
        registry.availability(settings).items())}
    lines = diagnostics.build_report(movies, cache, status)
    xbmcgui.Dialog().textviewer('Titanium X — Diagnostics',
                                '\n'.join(lines))


def main():
    choice = xbmcgui.Dialog().select(
        'Titanium X Artwork Downloader Pro',
        ['Enrich popular catalog now (engine demo)',
         'Diagnostics',
         'Settings'])
    if choice == 0:
        cache = cache_mod.ArtworkCache(profile_dir())
        progress = xbmcgui.DialogProgress()
        progress.create('Titanium X', 'Enriching artwork…')
        movies = enrich.enrich_catalog(
            cache, ADDON.getSetting('fanarttv_key'),
            ADDON.getSetting('tmdb_key'), limit=20)
        progress.close()
        have_disc = sum(1 for m in movies if m['art'].get('discart'))
        xbmcgui.Dialog().notification(
            'Titanium X',
            '%d titles enriched, %d with disc art'
            % (len(movies), have_disc), time=5000)
    elif choice == 1:
        show_diagnostics()
    elif choice == 2:
        ADDON.openSettings()


if __name__ == '__main__':
    main()
