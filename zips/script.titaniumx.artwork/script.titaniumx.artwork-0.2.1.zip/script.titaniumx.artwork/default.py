#!/usr/bin/env python3
"""Titanium X Artwork Downloader Pro — dashboard (Phase 2 UI).

Menu: Download missing artwork (bulk job) · Artwork Manager
(alternatives gallery -> override + lock) · Enrich popular catalog ·
Diagnostics · Settings. Kodi-dialog code: implemented, pending
Shield verification (see docs/AUDIT-v0.2.0.md status taxonomy)."""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
sys.path.append(xbmc.translatePath(
    'special://home/addons/script.module.titaniumx.artwork/resources/lib'))

from titaniumx import cache as cache_mod          # noqa: E402
from titaniumx import diagnostics, enrich, jobs   # noqa: E402
from titaniumx import providers, registry         # noqa: E402

CHANGE_KEYS = ('poster', 'fanart', 'clearlogo', 'clearart',
               'characterart', 'keyart', 'discart', 'banner')


def profile_dir():
    from titaniumx import cache as _tc
    return _tc.shared_cache_dir()


def keys():
    return ADDON.getSetting('fanarttv_key'), ADDON.getSetting('tmdb_key')


def job_download_missing():
    fanart_key, tmdb_key = keys()
    cache = cache_mod.ArtworkCache(profile_dir())
    movies = providers.cinemeta_popular(20)
    progress = xbmcgui.DialogProgress()
    progress.create('Titanium X', 'Scanning for missing artwork…')

    def cb(done, total, title):
        if total:
            progress.update(int(done * 100 / total),
                            'Enriching: %s' % title)

    stats = jobs.download_missing(movies, cache, fanart_key, tmdb_key,
                                  progress=cb,
                                  cancelled=progress.iscanceled)
    progress.close()
    xbmcgui.Dialog().notification(
        'Titanium X',
        'Processed %d titles, %d improved%s'
        % (stats['processed'], stats['improved'],
           ' (cancelled)' if stats['cancelled'] else ''), time=6000)


def artwork_manager():
    fanart_key, tmdb_key = keys()
    cache = cache_mod.ArtworkCache(profile_dir())
    movies = providers.cinemeta_popular(20)
    dialog = xbmcgui.Dialog()
    pick = dialog.select('Artwork Manager — choose a title',
                         [m['title'] for m in movies])
    if pick < 0:
        return
    movie = movies[pick]
    while True:
        current = cache.get(movie['imdb'])
        labels = []
        for key in CHANGE_KEYS:
            state = 'set' if current.get(key) else 'missing'
            if cache.is_locked(movie['imdb'], key):
                state += ', locked'
            labels.append('Change %s (%s)' % (key, state))
        labels += ['Refresh all artwork', 'Restore original artwork',
                   'Back']
        choice = dialog.select('Artwork Manager — %s' % movie['title'],
                               labels)
        if choice < 0 or choice == len(labels) - 1:
            return
        if labels[choice] == 'Refresh all artwork':
            cache.db.execute('DELETE FROM artwork WHERE imdb=?',
                             (movie['imdb'],))
            cache.db.commit()
            enrich.enrich_movie(movie, cache, fanart_key, tmdb_key)
            continue
        if labels[choice] == 'Restore original artwork':
            cache.db.execute('DELETE FROM overrides WHERE imdb=?',
                             (movie['imdb'],))
            cache.db.execute('DELETE FROM locks WHERE imdb=?',
                             (movie['imdb'],))
            cache.db.commit()
            continue
        key = CHANGE_KEYS[choice]
        alts = providers.alternatives(movie, fanart_key,
                                      tmdb_key).get(key, [])
        if not alts:
            dialog.notification(
                'Titanium X',
                'No alternatives for %s (add API keys in Settings)'
                % key, time=5000)
            continue
        items = []
        for url in alts:
            li = xbmcgui.ListItem(label=os.path.basename(url)[:60])
            li.setArt({'thumb': url, 'icon': url})
            items.append(li)
        sel = dialog.select('Choose %s — %s' % (key, movie['title']),
                            items, useDetails=True)
        if sel >= 0:
            cache.set_override(movie['imdb'], key, url=alts[sel])
            if dialog.yesno('Titanium X',
                            'Lock this %s so refreshes never '
                            'replace it?' % key):
                cache.lock(movie['imdb'], key)


def show_diagnostics():
    fanart_key, tmdb_key = keys()
    cache = cache_mod.ArtworkCache(profile_dir())
    movies = enrich.enrich_catalog(cache, fanart_key, tmdb_key,
                                   limit=20)
    settings = {'fanarttv_key': fanart_key, 'tmdb_key': tmdb_key}
    status = {'Providers': ', '.join(
        '%s=%s' % (k, v) for k, v in
        registry.availability(settings).items())}
    lines = diagnostics.build_report(movies, cache, status)
    xbmcgui.Dialog().textviewer('Titanium X — Diagnostics',
                                '\n'.join(lines))


def main():
    choice = xbmcgui.Dialog().select(
        'Titanium X Artwork Downloader Pro',
        ['Download missing artwork',
         'Artwork Manager (change / lock artwork)',
         'Enrich popular catalog now',
         'Diagnostics',
         'Settings'])
    if choice == 0:
        job_download_missing()
    elif choice == 1:
        artwork_manager()
    elif choice == 2:
        cache = cache_mod.ArtworkCache(profile_dir())
        fanart_key, tmdb_key = keys()
        movies = enrich.enrich_catalog(cache, fanart_key, tmdb_key,
                                       limit=20)
        xbmcgui.Dialog().notification(
            'Titanium X', '%d titles enriched' % len(movies), time=4000)
    elif choice == 3:
        show_diagnostics()
    elif choice == 4:
        ADDON.openSettings()


if __name__ == '__main__':
    main()
