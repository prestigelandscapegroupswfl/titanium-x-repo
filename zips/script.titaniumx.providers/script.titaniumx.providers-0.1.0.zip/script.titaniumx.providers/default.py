#!/usr/bin/env python3
"""Titanium X Universal Provider Manager.

Lists known compatible providers (official Kodi repo add-ons and
Titanium X's own). For each: status, Install (from its official
repository via Kodi's InstallAddon), Enable/Disable (JSON-RPC) and
Configure (the provider's own settings)."""
import json

import xbmc
import xbmcgui

PROVIDERS = [
    ('plugin.video.themoviedb.helper', 'TMDb Helper',
     'Catalogs + player routing to your providers'),
    ('plugin.video.torus', 'Torus',
     'Authorized source playback'),
    ('plugin.video.youtube', 'YouTube',
     'Trailers and video'),
    ('plugin.video.jellycon', 'JellyCon (Jellyfin)',
     'Your Jellyfin media server'),
    ('plugin.video.embycon', 'EmbyCon (Emby)',
     'Your Emby media server'),
    ('plugin.video.plexkodiconnect', 'PlexKodiConnect',
     'Your Plex media server'),
    ('pvr.iptvsimple', 'IPTV Simple Client',
     'Authorized IPTV playlists (PVR)'),
    ('plugin.video.titaniumx', 'Titanium X Catalog',
     'Titanium X dynamic catalogs'),
]


def rpc(method, params):
    raw = xbmc.executeJSONRPC(json.dumps(
        {'jsonrpc': '2.0', 'method': method, 'params': params,
         'id': 1}))
    return json.loads(raw).get('result', {})


def is_installed(addon_id):
    return xbmc.getCondVisibility(
        'System.HasAddon(%s)' % addon_id) == 1


def is_enabled(addon_id):
    res = rpc('Addons.GetAddonDetails',
              {'addonid': addon_id, 'properties': ['enabled']})
    return bool(res.get('addon', {}).get('enabled', True))


def manage(addon_id, name):
    dialog = xbmcgui.Dialog()
    installed = is_installed(addon_id)
    actions = []
    if not installed:
        actions.append('Install from official repository')
    else:
        actions.append('Disable' if is_enabled(addon_id) else 'Enable')
        actions.append('Configure (open its settings)')
    actions.append('Back')
    pick = dialog.select('%s — %s' % (name, 'installed' if installed
                                      else 'not installed'), actions)
    if pick < 0 or actions[pick] == 'Back':
        return
    choice = actions[pick]
    if choice.startswith('Install'):
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
    elif choice in ('Enable', 'Disable'):
        rpc('Addons.SetAddonEnabled',
            {'addonid': addon_id, 'enabled': choice == 'Enable'})
    elif choice.startswith('Configure'):
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % addon_id)


def main():
    dialog = xbmcgui.Dialog()
    while True:
        labels = ['%s — %s' % (name, 'installed' if is_installed(aid)
                               else 'not installed')
                  for aid, name, _d in PROVIDERS]
        labels.append('Done')
        pick = dialog.select('Titanium X Provider Manager', labels)
        if pick < 0 or pick == len(PROVIDERS):
            return
        aid, name, _d = PROVIDERS[pick]
        manage(aid, name)


if __name__ == '__main__':
    main()
